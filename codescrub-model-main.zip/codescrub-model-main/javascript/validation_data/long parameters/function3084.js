var t = function(assert, jQuery, window, document, test) {
    assert.expect(1);
    assert.ok(test.status, test.description);
}