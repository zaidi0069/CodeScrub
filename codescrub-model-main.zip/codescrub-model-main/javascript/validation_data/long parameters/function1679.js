var t = function(assert, jQuery, window, document, status) {
    assert.expect(1);
    assert.strictEqual(status, "success", "Request completed");
}