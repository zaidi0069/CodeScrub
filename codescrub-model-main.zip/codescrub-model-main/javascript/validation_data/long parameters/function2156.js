var t = function(assert, jQuery, window, document, result) {
    assert.expect(1);
    assert.equal(result, "ok", "enumeration of data- attrs on body");
}