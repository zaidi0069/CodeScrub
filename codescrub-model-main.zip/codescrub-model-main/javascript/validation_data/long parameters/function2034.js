var t = function(assert, jQuery, window, document, errors) {
    assert.expect(1);
    assert.deepEqual(errors, [], "jQuery loaded");
}