var t = function(a, b, c, e) {
    var f, g = d(a, null, e, []),
        h = a.length;
    while (h--)(f = g[h]) && (a[h] = !(b[h] = f))
}