var t = function() {
    return React.createElement(
        "div", {
            className: "_5ljl",
            id: "ads_pe_top_nav"
        },
        React.createElement(
            "div", {
                ref: "logo",
                className: "_5ljm"
            },
            React.createElement(Link0, null),
            React.createElement(
                "div", {
                    className: "_5rne"
                },
                React.createElement(
                    "span", {
                        className: "_5ljs",
                        "data-testid": "PETopNavLogoText"
                    },
                    "Power Editor"
                )
            ),
            React.createElement(
                "span", {
                    className: "_5ljt _5lju"
                },
                "Dick Madanson"
            )
        ),
        React.createElement(
            "div", {
                ref: "leftButtonGroup",
                className: "_5ljy"
            },
            React.createElement(
                "div", {
                    ref: "accountDropdown",
                    className: "_5ljz _5mun"
                },
                React.createElement(AdsPEAccountSelectorContainer8, null),
                React.createElement(
                    "div", {
                        className: "_5lj- _5lju"
                    },
                    "Account 10149999073643408"
                )
            ),
            React.createElement(
                "div", {
                    className: "_5ljz"
                },
                React.createElement(
                    "div", {
                        className: "_5lj_"
                    },
                    React.createElement(XUIButton10, null)
                ),
                React.createElement(
                    "div", {
                        className: "_5lj- _5lju"
                    },
                    React.createElement(DownloadUploadTimestamp11, null)
                )
            ),
            React.createElement(
                "div", {
                    className: "_5ljz"
                },
                React.createElement(
                    "div", {
                        className: "_5lj_"
                    },
                    React.createElement(XUIButton14, null)
                ),
                React.createElement(
                    "div", {
                        className: "_5lj- _5lju"
                    },
                    React.createElement(DownloadUploadTimestamp15, null)
                )
            )
        ),
        React.createElement(
            "div", {
                ref: "rightButtonGroup",
                className: "_5lk3"
            },
            React.createElement(XUIButtonGroup23, null)
        ),
        React.createElement(AdsPEResetDialog24, null)
    );
}