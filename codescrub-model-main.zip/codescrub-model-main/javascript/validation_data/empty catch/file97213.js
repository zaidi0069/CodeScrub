function V() {
    try {
        return o.activeElement;
    } catch (e) {}
}