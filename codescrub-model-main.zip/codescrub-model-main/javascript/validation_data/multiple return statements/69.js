const findConsecutiveSum = (arr, targetSum) => {
    if (!Array.isArray(arr) || isNaN(targetSum)) {
        return "Invalid input";
    }
    let start = 0;
    let end = 0;
    let sum = arr[0];
    while (end < arr.length) {
        if (sum === targetSum) {
            return arr.slice(start, end + 1);
        }
        if (sum < targetSum) {
            end++;
            sum += arr[end];
        } else {
            sum -= arr[start];
            start++;
        }
    }
    return "No consecutive sum found";
};