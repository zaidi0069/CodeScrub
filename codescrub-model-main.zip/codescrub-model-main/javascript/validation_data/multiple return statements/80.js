function generateFibonacciSeries(n) {
    if (isNaN(n) || n <= 0) {
        return "Invalid input";
    }
    const fibonacciSeries = [0, 1];
    for (let i = 2; i < n; i++) {
        fibonacciSeries.push(fibonacciSeries[i - 1] + fibonacciSeries[i - 2]);
    }
    return fibonacciSeries;
}