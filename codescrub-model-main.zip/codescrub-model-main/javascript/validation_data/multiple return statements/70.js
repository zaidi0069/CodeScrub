const findPerfectNumbersInRange = function(start, end) {
    if (isNaN(start) || isNaN(end) || start <= 0 || end <= 0 || start > end) {
        return "Invalid input";
    }
    const perfectNumbers = [];
    for (let num = start; num <= end; num++) {
        let sum = 0;
        for (let i = 1; i < num; i++) {
            if (num % i === 0) {
                sum += i;
            }
        }
        if (sum === num) {
            perfectNumbers.push(num);
        }
    }
    return perfectNumbers;
};