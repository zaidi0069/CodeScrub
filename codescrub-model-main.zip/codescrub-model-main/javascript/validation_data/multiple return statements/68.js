function checkPangram(sentence) {
    if (typeof sentence !== "string") {
        return "Input is not a string";
    }
    const alphabet = "abcdefghijklmnopqrstuvwxyz";
    const lowercaseSentence = sentence.toLowerCase();
    for (let char of alphabet) {
        if (!lowercaseSentence.includes(char)) {
            return false;
        }
    }
    return true;
}