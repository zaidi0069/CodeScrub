function countNonRepeatingChars(str) {
    if (typeof str !== "string") {
        return "Input is not a string";
    }
    const charCount = {};
    for (let char of str) {
        charCount[char] = (charCount[char] || 0) + 1;
    }
    return Object.values(charCount).filter(count => count === 1).length;
}