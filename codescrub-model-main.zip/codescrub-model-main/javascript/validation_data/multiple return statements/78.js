const findMedianOfThree = (num1, num2, num3) => {
    if (isNaN(num1) || isNaN(num2) || isNaN(num3)) {
        return "Invalid input";
    }
    const nums = [num1, num2, num3].sort((a, b) => a - b);
    return nums[1];
};