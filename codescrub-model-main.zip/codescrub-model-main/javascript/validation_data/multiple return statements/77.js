function findSubstringOccurrencesIndex(str, substr) {
    if (typeof str !== "string" || typeof substr !== "string") {
        return "Input is not a string";
    }
    const indexes = [];
    let index = str.indexOf(substr);
    while (index !== -1) {
        indexes.push(index);
        index = str.indexOf(substr, index + 1);
    }
    return indexes.length === 0 ? "Substring not found" : indexes;
}