function findConsonants(str) {
    if (typeof str !== "string") {
        return "Input is not a string";
    }
    const vowels = "aeiou";
    return str.split("").filter(char => !vowels.includes(char.toLowerCase())).join("");
}