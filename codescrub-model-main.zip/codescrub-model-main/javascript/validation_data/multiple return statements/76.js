const findOddDigitsCount = function(num) {
    if (isNaN(num) || num < 0) {
        return "Invalid input";
    }
    const numStr = num.toString();
    return numStr.split("").filter(digit => parseInt(digit) % 2 !== 0).length;
};