    public void updated(Map<String, Object> properties) {
        logger.debug("Updating Cloud Publisher...");

        doUpdate(properties);

        logger.debug("Updating Cloud Publisher... Done");
    }