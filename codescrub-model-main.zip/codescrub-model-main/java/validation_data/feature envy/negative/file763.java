    public AdvertisingReportEventType getEventType() {
        return this.eventType;
    }