	public IRIFunction(ValueExpr arg) {
		super(arg);
	}