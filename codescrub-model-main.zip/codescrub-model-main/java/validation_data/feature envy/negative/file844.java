	public QueueCursor(int capacity) {
		this(capacity, false);
	}