    private static String[] getColumnProperties() {
        final String[] columnProperties = new String[COLUMN_DATA.length];
        for (int i = 0; i < columnProperties.length; i++) {
            columnProperties[i] = COLUMN_DATA[i].name;
        }
        return columnProperties;
    }