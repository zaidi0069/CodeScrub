	CssRecord( Module module, DesignElement element, CssStyleSheet css,
			boolean add, int pos )
	{
		this.module = module;
		this.element = element;
		this.css = css;
		this.add = add;
		this.position = pos;
	}