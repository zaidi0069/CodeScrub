    public LoginButton(Context context) {
        super(
                context,
                null,
                0,
                0,
                AnalyticsEvents.EVENT_LOGIN_BUTTON_CREATE,
                AnalyticsEvents.EVENT_LOGIN_BUTTON_DID_TAP);
    }