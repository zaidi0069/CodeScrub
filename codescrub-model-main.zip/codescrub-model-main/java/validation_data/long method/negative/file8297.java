    public Collector setIncomingMinorFragmentList(List<Integer> incomingMinorFragment)
    {
        this.incomingMinorFragment = incomingMinorFragment;
        return this;
    }