public class WorkItemTypeTemplate {

    private String template;

    public String getTemplate() {
        return template;
    }

    public void setTemplate(final String template) {
        this.template = template;
    }
}