      @AutoValue
      public abstract static class CreatePayload {

         public abstract String name();

         public abstract Location location();

      }