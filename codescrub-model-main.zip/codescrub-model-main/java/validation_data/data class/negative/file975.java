    interface ToolWindows {
      String TOOL_WINDOWS = ASSISTANT_MENU_PREFIX + "toolWindows";
      String CONTRIBUTE_TOOL_WIDOWS =
          ASSISTANT_MENU_PREFIX + "Tool Windows/contributePartDisplayingMode";
    }