public class WigFile extends FeatureFile {
    public WigFile() {
        setFormat(BiologicalDataItemFormat.WIG);
    }
}