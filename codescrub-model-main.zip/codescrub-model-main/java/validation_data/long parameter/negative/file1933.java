    public void setTmfeIsSet(boolean value) {
      if (!value) {
        this.tmfe = null;
      }
    }