  protected void addRequiredAlertProperties(Set<String> properties) {
    properties.add(AlertResourceProvider.ALERT_STATE);
    properties.add(AlertResourceProvider.ALERT_ORIGINAL_TIMESTAMP);
    properties.add(AlertResourceProvider.ALERT_MAINTENANCE_STATE);
  }