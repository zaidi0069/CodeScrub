  public void setTimeCreated(Long timeCreated) {
    this.timeCreated = timeCreated;
  }