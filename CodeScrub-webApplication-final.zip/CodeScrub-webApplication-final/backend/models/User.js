const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    login: { type: String, required: true },
    email: { type: String },
    web_url: { type: String },
    public_repos: { type: Number, default:0 },
    total_private_repos: { type: Number , default:0},
    platform: { type: String, required: true } ,
    scanResults: [
        {
          results: Object, 
          repository: String, 
          branch: String,
          generatedAt: {
            type: Date,
            default: Date.now, 
          },
        },
      ]
});

module.exports = mongoose.model("User", userSchema);
