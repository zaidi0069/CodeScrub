const User = require("../models/User");
const fetch = require("node-fetch");

const getGitUserAccessToken = async (req, res) => {
    try {
        
        // Fetching access token from GitHub
        const { userAuthCode } = req.body;
        const reqQueryParams = `?client_id=${process.env.CLIENT_ID}&client_secret=${process.env.CLIENT_SECRET}&code=${userAuthCode}`;
        // fetching the access token from github api
        const response = await fetch(`https://github.com/login/oauth/access_token${reqQueryParams}`, {
            method: "POST",
            headers: {
                "Accept": "application/json"
            }
        });

        const jsonresponse = await response.json();
        if (jsonresponse.error) {
            console.error("Error fetching access token:", jsonresponse.error);
            throw new Error("Failed to fetch access token");
        }
        

        //now fetching user's github profile information

        const profileResponse = await fetch("https://api.github.com/user", {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${jsonresponse.access_token}`
            }
        });

        if (profileResponse.status == 401)
            throw new Error("Failed to fetch profile");

        const profileres = await profileResponse.json();
        const {
            login,
            email,
            avatar_url,
            html_url,
            public_repos,
            total_private_repos,
        } = profileres;


        const profileInfo = { login, email, avatar_url, web_url: html_url, public_repos, total_private_repos };
        // Save user to database
        const user = await User.findOneAndUpdate(
            { platform: "github", login },
            { login, email, web_url: html_url, public_repos, total_private_repos, platform: "github" },
            { upsert: true, new: true } // Create if not exists
        );

        console.log("hello")

        res.status(201).json({ status: 201, jsonresponse, profileInfo });

        // if token is valid then the response status code is 200
        // if token is not valid or expired then the status code is 401
    }
    catch (error) {
        res.status(422).json({ status: 422, message: "error occured" });
    }
}


const getGitlabUserAccessToken = async (req, res) => {
    try {
        const { userAuthCode } = req.body;

        // Fetching the access token from GitLab
        const reqQueryParams = `?client_id=${process.env.GITLAB_CLIENT_ID}&client_secret=${process.env.GITLAB_CLIENT_SECRET}&code=${userAuthCode}&grant_type=authorization_code&redirect_uri=http://15.206.242.87:3000/dashboard/gitlab`;

        const response = await fetch(`https://gitlab.com/oauth/token`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                client_id: process.env.GITLAB_CLIENT_ID,
                client_secret: process.env.GITLAB_CLIENT_SECRET,
                code: userAuthCode,
                grant_type: "authorization_code",
                redirect_uri: "http://15.206.242.87:3000/dashboard/gitlab"
            })
        });

        const jsonresponse = await response.json();
        if (jsonresponse.error) {
            console.error("Error fetching access token:", jsonresponse.error);
            throw new Error("Failed to fetch access token");
        }



        // Now fetching user's GitLab profile information
        const profileResponse = await fetch("https://gitlab.com/api/v4/user", {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${jsonresponse.access_token}`
            }
        });

        if (profileResponse.status == 401) {
            throw new Error("Failed to fetch profile");
        }

        const profileres = await profileResponse.json();
        const { username, email, avatar_url, web_url } = profileres;
        const profileInfo = { login: username, email, avatar_url, web_url };

        // Save or update the user in the database
        const user = await User.findOneAndUpdate(
            { platform: "gitlab", login: username },
            { login: username, email, web_url, platform: "gitlab" },
            { upsert: true, new: true }
        );

        res.status(201).json({ status: 201, jsonresponse, profileInfo });
    } catch (error) {
        console.error("Error occurred:", error);
        res.status(422).json({ status: 422, message: "Error occurred" });
    }
}


const getBitbucketUserAccessToken = async (req, res) => {
    try {
        const { userAuthCode } = req.body;
        const params = new URLSearchParams();
        params.append('grant_type', 'authorization_code');
        params.append('code', userAuthCode);
        const authheader = `Basic ${Buffer.from(`${process.env.BITBUCKET_CLIENT_ID}:${process.env.BITBUCKET_CLIENT_SECRET}`).toString('base64')}`;
        const response = await fetch("https://bitbucket.org/site/oauth2/access_token", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                "Authorization": authheader
            },
            body: params
        });

        const jsonresponse = await response.json();
     
        if (jsonresponse.error)
            throw new Error();

        /* now fetching user's bitbucket profile information */
        const profileResponse = await fetch("https://api.bitbucket.org/2.0/user", {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${jsonresponse.access_token}`
            }
        });

        if (profileResponse.status == 401)
            throw new Error();
        const profileres = await profileResponse.json();

        /* getting email of user */
        const emailResponse = await fetch("https://api.bitbucket.org/2.0/user/emails", {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${jsonresponse.access_token}`
            }
        });
        if (emailResponse.status == 401)
            throw new Error();
        const emailres = await emailResponse.json();

        const profileInfo = {
            login: profileres.username,
            avatar_url: profileres.links.avatar.href,
            web_url: profileres.links.html.href,
            email: emailres.values[0].email,

        };

        // Save or update the user in the database
        const user = await User.findOneAndUpdate(
            { platform: "bitbucket", login: profileInfo.login },
            { login: profileInfo.login, email: profileInfo.email, web_url: profileInfo.web_url, platform: "bitbucket" },
            { upsert: true, new: true } // Create if not exists
        );

        
        res.status(201).json({ status: 201, jsonresponse, profileInfo });
    }
    catch (error) {
        res.status(422).json({ status: 422, message: "error occured" });
    }
}







const getscanhistory = async (req, res) => {
    try {
        const { web_url } = req.body;


        const user = await User.findOne(
            { web_url },
        );

        if (user) {
            res.status(201).json(user.scanResults);
        }


        else {
            res.status(404).json({ message: "user not found" })
        }
    }
    catch (error) {
        res.status(422).json({ status: 422, message: "error occured" });
    }
}

const deletescannedresult = async (req, res) => {
    try {
        const { web_url, generatedAt } = req.body;

        const user = await User.findOne({ web_url });

        if (user) {
            const result = await User.updateOne(
                { web_url, "scanResults.generatedAt": generatedAt }, 
                { $pull: { scanResults: { generatedAt } } }
            );

            if (result.modifiedCount === 0) {
                return res.status(404).json({ message: "Scan result not found" });
            }

            return res.status(200).json({ message: "Scan result deleted successfully" });
        } else {
            res.status(404).json({ message: "User not found" });
        }
    } catch (error) {
        console.error(error);
        res.status(422).json({ status: 422, message: "Error occurred" });
    }
};







module.exports = {
    getGitUserAccessToken,
    getGitlabUserAccessToken,
    getBitbucketUserAccessToken,
    getscanhistory,
    deletescannedresult
}






