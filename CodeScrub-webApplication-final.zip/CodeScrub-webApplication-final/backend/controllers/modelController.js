const User = require("../models/User");
const scanRepository = async (req, res) => {
    try {
        const { sourceCodeFiles, web_url, repository, branch } = req.body;
        console.log("x")
        const results = {};
        const promises = Object.keys(sourceCodeFiles).map(async (key) => {
            const singleFile = {};
            singleFile[key] = sourceCodeFiles[key];
            const flaskendpoint = key.includes(".java") ? "http://127.0.0.1:9005/java" : "http://127.0.0.1:9005/javascript";
            const flaskresponse = await fetch(flaskendpoint, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(singleFile)
            });

            const flaskres = await flaskresponse.json();
            if (flaskres[Object.keys(flaskres)[0]] != "clean")
                results[key] = flaskres[Object.keys(flaskres)[0]];
        })

        await Promise.all(promises);
        if (Boolean(!results)) {
            res.status(201).json({ respository: "clean" })
            return;
        }

        try {
            const updatedUser = await User.findOneAndUpdate(
                { web_url }, 
                { $push: { scanResults: { results, repository, branch,  generatedAt: Date.now() } } }, 
                { new: true, upsert: false } 
            );
        
            if (!updatedUser) {
                console.error("No user found with the provided web_url");
            }
        } catch (error) {
            console.error("Error updating user:", error);
        }


        res.status(201).json(results);
    }
    catch (error) {
        res.status(422).json({ message: "some error popped out :(" })
    }
}

module.exports = {
    scanRepository
}