const express = require("express");
const router = express.Router();
const {scanRepository} = require("../controllers/modelController");

/* Route for Scanning a Repository */
router.post("/scanRepository", scanRepository)

module.exports = router;