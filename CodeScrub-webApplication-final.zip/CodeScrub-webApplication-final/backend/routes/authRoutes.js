const express = require("express");
const router = express.Router();
const {
    getGitUserAccessToken,
    getGitlabUserAccessToken,
    getBitbucketUserAccessToken, 
    getscanhistory,
    deletescannedresult
} = require("../controllers/authController");


/* GitHub Authentication Route*/
router.post("/getGitAccessToken", getGitUserAccessToken);

/* GitLab Authentication Route*/
router.post("/getGitlabAccessToken", getGitlabUserAccessToken);

/* BitBucket Authentication Route*/
router.post("/getBitbucketAccessToken", getBitbucketUserAccessToken);

router.post("/getscanhistory", getscanhistory);

router.post("/deletescannedresult", deletescannedresult)

module.exports = router;