const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const dotenv = require("dotenv");
const bodyParser = require("body-parser");
const authRouter = require("./routes/authRoutes");
const modelRouter= require("./routes/modelRoutes")
const mongoose = require("mongoose")

dotenv.config();
const server = express();
server.disable("etag");


/* Middlewares Configuration */
server.use(express.json());
server.use(bodyParser.json({limit : "500mb", extended : true}));
server.use(bodyParser.urlencoded({limit : "500mb", extended : true}));

server.use(helmet());
server.use(helmet.crossOriginResourcePolicy({policy : "cross-origin"}));
server.use("*", cors({
    origin : true,
    credentials : true
}));

/* Database connection */
mongoose
    .connect(process.env.dbURI, { useNewUrlParser: true, useUnifiedTopology: true, family: 4 })
    .then(() => console.log("Connected to MongoDB"))
    .catch((err) => {
        console.error("Failed to connect to MongoDB", err);
        process.exit(1); 
    });

server.use("/auth", authRouter);
server.use("/model", modelRouter)
const port = process.env.PORT || 8000;


server.listen(port, () => {
    console.log(`Server running on port ${port}`);
})
