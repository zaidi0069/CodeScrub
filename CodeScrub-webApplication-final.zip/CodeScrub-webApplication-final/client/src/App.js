import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Homepage from './scenes/Homepage';
import Dashboard  from './scenes/Dashboard';
import DisplayRepo from './scenes/DisplayRepo';
import File from './scenes/File';
import ResultsPage from './scenes/ResultsPage';
import RepositoryTree from './scenes/RepositoryTree';
import SmellInfo from './scenes/SmellInfo';
import ScanHistory from './scenes/ScanHistory'

const App = () => {

  const token = useSelector(state => state.token);
  const authTokenType = useSelector(state => state.authTokenType);

  return (
    <>
        <Routes>
            <Route path="/" element={Boolean(token) ? <Navigate to={`/dashboard/${authTokenType}`}/> : <Homepage/>}/>
            <Route path="/dashboard/:appname" element={<Dashboard/>}/>
            <Route path="/repository/:reponame/:branch/*" element={Boolean(token) ? <DisplayRepo/> : <Navigate to={"/"}/>} />
            <Route path="/tree/:reponame/:branch/*" element={Boolean(token) ? <RepositoryTree/> : <Navigate to={"/"}/>} />
            <Route path="/file/:reponame/:branch/*" element={Boolean(token) ? <File/> : <Navigate to={"/"}/>} />
            <Route path="/resultspage" element={ <ResultsPage/> } />
            <Route path="/*" element={<Navigate to="/"/>} />
            <Route path="/smell-info" element={<SmellInfo/>}/>
            <Route path="/scanhistory" element={Boolean(token) ? <ScanHistory/> : <Navigate to={"/"}/>} />
        </Routes>
    </>
  )
}

export default App;