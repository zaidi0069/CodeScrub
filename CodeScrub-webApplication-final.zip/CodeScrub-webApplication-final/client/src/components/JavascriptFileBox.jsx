import React from "react";
import {
    Box,
    Divider,
    useMediaQuery,
} from "@mui/material";
import Text from "./Text";

const JavascriptFileBox = ({ javascriptFile }) => {
    const isLargeScreen = useMediaQuery("(min-width:700px)");
    const fileName = Object.keys(javascriptFile)[0];

    return (
        <Box
            backgroundColor="white"
            borderRadius="10px"
            margin={isLargeScreen ? "30px 0px" : "20px 0px"}
            padding={isLargeScreen ? "2rem 3rem" : "1rem 1.5rem"}
            width="100%"
            boxSizing="border-box"
            overflow="hidden"
        >
            <Text
                textAlign="center"
                fontWeight="bolder"
                fontSize={isLargeScreen ? "1.8rem" : "1.4rem"}
                sx={{
                    wordBreak: "break-word",
                }}
            >
                {fileName}
            </Text>

            <Divider
                sx={{
                    borderBottomWidth: "1.5px",
                    width: isLargeScreen ? "80%" : "90%",
                    marginTop: "1.2rem",
                    marginLeft: "auto",
                    marginRight: "auto",
                }}
            />

            {javascriptFile[fileName] === "error" ? (
                <Text
                    fontSize={isLargeScreen ? "1.3rem" : "1rem"}
                    margin={isLargeScreen ? "4rem" : "2rem"}
                    sx={{
                        wordBreak: "break-word",
                    }}
                >
                    Some syntax error was found during the parsing of this file.
                </Text>
            ) : (
                <>
                    {Object.keys(javascriptFile[fileName]).map((item, index) => (
                        <Box
                            key={index}
                            margin={isLargeScreen ? "4rem 0rem" : "2rem 0rem"}
                        >
                            {javascriptFile[fileName][item].map((element, number) => (
                                <React.Fragment key={`${item}-${number}`}>
                                    {number === 0 ? (
                                        <Box>
                                            <pre style={{ whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
                                                <Text
                                                    fontSize={isLargeScreen ? "1.2rem" : "1rem"}
                                                    marginBottom={isLargeScreen ? "60px" : "30px"}
                                                    overflow="auto"
                                                    sx={{
                                                        wordBreak: "break-word",
                                                    }}
                                                >
                                                    {element}
                                                </Text>
                                                <Text
                                                    fontSize={isLargeScreen ? "1.2rem" : "1rem"}
                                                    margin={isLargeScreen ? "30px 0px" : "15px 0px"}
                                                    fontWeight="bolder"
                                                    sx={{
                                                        wordBreak: "break-word",
                                                    }}
                                                >
                                                    Following code smells are found in the above code segment:
                                                </Text>
                                            </pre>
                                        </Box>
                                    ) : (
                                        <Text
                                            fontSize={isLargeScreen ? "1.2rem" : "1rem"}
                                            width="100%"
                                            margin={isLargeScreen ? "30px auto" : "15px auto"}
                                            color="red"
                                            sx={{
                                                wordBreak: "break-word",
                                            }}
                                        >
                                            <ul>
                                                <li>{element}</li>
                                            </ul>
                                        </Text>
                                    )}
                                </React.Fragment>
                            ))}

                            {index < Object.keys(javascriptFile[fileName]).length - 1 && (
                                <Divider
                                    sx={{
                                        borderBottomWidth: "1.5px",
                                        margin: isLargeScreen ? "3rem 0" : "1.5rem 0",
                                    }}
                                />
                            )}
                        </Box>
                    ))}
                </>
            )}
        </Box>
    );
};

export default JavascriptFileBox;
