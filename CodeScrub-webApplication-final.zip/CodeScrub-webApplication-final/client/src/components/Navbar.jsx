import React, { useState } from "react";
import {
    useMediaQuery,
    Button,
    MenuItem,
    InputBase,
    Select,
    FormControl,
    Box,
    IconButton
} from "@mui/material";
import {
    Menu,
    Close,
    Logout
} from "@mui/icons-material";
import FlexBetween from "./FlexBetween";
import Text from "./Text";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { setLogout } from "../reduxState";

const Navbar = ({ pageType, getStartedRef }) => {

    const isLargeScreen = useMediaQuery("(min-width:1000px)");
    const gitProfile = useSelector(state => state.gitProfile);
    const authTokenType = useSelector(state => state.authTokenType);
    const [isMobileMenuToggled, setIsMobileMenuToggled] = useState(false);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    // Function for scrolling to bottom
    const scrollDown = () => {
        if (isMobileMenuToggled)
            setIsMobileMenuToggled(false);
        window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "smooth"
        });
    }

    return (
        <>
            <FlexBetween
                height="15vh"
                backgroundColor="#0a3d62"
                padding="15px 6%"
                boxShadow="2px 2px 2px 0.2px silver"
                sx={{
                    position: "sticky",
                    top: 0, 
                    zIndex: 10,
                }}
            >
                <Text
                    onClick={() => navigate("/")}
                    sx={{
                        fontFamily: "Protest Riot, sans-serif",
                        fontSize: "2rem",
                        color: "white",
                        "&:hover": { cursor: "pointer" }
                    }}
                >
                    Code Scrub
                </Text>

                {isLargeScreen ? (
                    <FlexBetween gap="40px">
                        {!gitProfile && pageType === "smellinfopage" ? (
                            <Text
                                sx={{ color: "white", "&:hover": {
                                            cursor: "pointer",
                                            transform: "scale(1.09)"
                                        } }}
                                onClick={() => navigate("/")}
                            >
                                Home
                            </Text>
                        ) : !gitProfile ? (
                            <FlexBetween gap="25px">
                                <Text
                                    color="white"
                                    sx={{
                                        "&:hover": {
                                            cursor: "pointer",
                                            transform: "scale(1.09)"
                                        }
                                    }}
                                    onClick={scrollDown}
                                >
                                    About
                                </Text>
                                <Button
                                    sx={{ color: "white", backgroundColor: "#00b894" }}
                                    onClick={() => {
                                        getStartedRef.current.scrollIntoView({ behavior: "smooth" });
                                    }}
                                >
                                    Sign In
                                </Button>
                            </FlexBetween>
                        ) : (
                            <FlexBetween gap="40px">
                                <FlexBetween gap="25px">
                                    <FormControl variant="standard" value={gitProfile.login}>
                                        <Select
                                            value={gitProfile.login}
                                            sx={{
                                                backgroundColor: "#BFC9CA",
                                                width: "150px",
                                                borderRadius: "5px",
                                                padding: "0px 7px",
                                                marginLeft: "20px",
                                                "& .MuiSvgIcon-root": { width: "2rem" },
                                            }}
                                            input={<InputBase />}
                                        >
                                            <MenuItem value={gitProfile.login}>{gitProfile.login}</MenuItem>
                                        </Select>
                                    </FormControl>
                                    <Box
                                        width="50px"
                                        height="50px"
                                        sx={{ "&:hover": { cursor: "pointer" } }}
                                        onClick={() => {
                                            window.open(
                                                authTokenType === "github" ? gitProfile.html_url : gitProfile.web_url,
                                                "_blank"
                                            );
                                        }}
                                    >
                                        <img
                                            src={`${gitProfile.avatar_url}`}
                                            alt="Profile"
                                            style={{
                                                height: "100%",
                                                width: "100%",
                                                objectFit: "cover",
                                                borderRadius: "50%"
                                            }}
                                        />
                                    </Box>
                                </FlexBetween>

                                <Button
                                    sx={{ color: "white", backgroundColor: "#00b894" }}
                                    onClick={() => {
                                        dispatch(setLogout());
                                        navigate("/");
                                    }}
                                >
                                    <FlexBetween gap="10px">
                                        <Text fontSize=".7rem">Log Out</Text>
                                        <Logout sx={{ fontSize: "20px" }} />
                                    </FlexBetween>
                                </Button>
                            </FlexBetween>
                        )}
                    </FlexBetween>
                ) : (
                    // Mobile View: Menu Icon
                    <IconButton
                        onClick={() => setIsMobileMenuToggled(!isMobileMenuToggled)}
                    >
                        {isMobileMenuToggled ? (
                            <Close
                                sx={{
                                    color: "white",
                                    fontSize: "40px",
                                    "&:hover": {
                                        transform: "scale(1.09)",
                                        cursor: "pointer"
                                    }
                                }}
                            />
                        ) : (
                            <Menu
                                sx={{
                                    color: "white",
                                    fontSize: "40px",
                                    "&:hover": {
                                        transform: "scale(1.09)",
                                        cursor: "pointer"
                                    }
                                }}
                            />
                        )}
                    </IconButton>
                )}
            </FlexBetween>

            {/* Mobile Menu */}
            {!isLargeScreen && isMobileMenuToggled && (
                <Box
                    position="fixed"
                    right="0px"
                    top="5rem"
                    width="45%"
                    height="auto"
                    zIndex="10"
                    boxShadow="0px 0px 1px 3px silver"
                    borderRadius="2px"
                    backgroundColor="#BFC9CA"
                    padding="30px 0px"
                    overflow="auto"
                >
                    <Box
                        gap="30px"
                        display="flex"
                        flexDirection="column"
                        justifyContent="center"
                        alignItems="center"
                        sx={{ padding: "0 20px" }}
                    >
                        {!gitProfile && pageType === "smellinfopage" ? (
                            <Text
                                color="white"
                                sx={{
                                    "&:hover": {
                                        cursor: "pointer",
                                        transform: "scale(1.09)"
                                    }
                                }}
                                onClick={() => {
                                    navigate("/");
                                    setIsMobileMenuToggled(false);
                                }}
                            >
                                Home
                            </Text>
                        ) : !gitProfile ? (
                            <>
                                <Text
                                    color="white"
                                    sx={{
                                        "&:hover": {
                                            cursor: "pointer",
                                            transform: "scale(1.09)"
                                        }
                                    }}
                                    onClick={scrollDown}
                                >
                                    About
                                </Text>
                                <Button
                                    sx={{ color: "white", backgroundColor: "#00b894" }}
                                    onClick={() => {
                                        getStartedRef.current.scrollIntoView({ behavior: "smooth" });
                                        setIsMobileMenuToggled(false);
                                    }}
                                >
                                    Sign In
                                </Button>
                            </>
                        ) : (
                            <>
                                <FormControl variant="standard" value={gitProfile.login}>
                                    <Select
                                        value={gitProfile.login}
                                        sx={{
                                            backgroundColor: "#BFC9CA",
                                            width: "150px",
                                            borderRadius: "5px",
                                            padding: "0px 7px",
                                            marginLeft: "20px",
                                            "& .MuiSvgIcon-root": { width: "2rem" },
                                        }}
                                        input={<InputBase />}
                                    >
                                        <MenuItem value={gitProfile.login}>{gitProfile.login}</MenuItem>
                                    </Select>
                                </FormControl>
                                <Box
                                    width="50px"
                                    height="50px"
                                    sx={{ "&:hover": { cursor: "pointer" } }}
                                    onClick={() => {
                                        window.open(
                                            authTokenType === "github" ? gitProfile.html_url : gitProfile.web_url,
                                            "_blank"
                                        );
                                    }}
                                >
                                    <img
                                        src={`${gitProfile.avatar_url}`}
                                        alt="Profile"
                                        style={{
                                            height: "100%",
                                            width: "100%",
                                            objectFit: "cover",
                                            borderRadius: "50%"
                                        }}
                                    />
                                </Box>
                                <Button
                                    sx={{ color: "white", backgroundColor: "#00b894", marginTop: "20px" }}
                                    onClick={() => {
                                        dispatch(setLogout());
                                        navigate("/");
                                    }}
                                >
                                    <FlexBetween gap="10px">
                                        <Text fontSize=".7rem">Log Out</Text>
                                        <Logout sx={{ fontSize: "20px" }} />
                                    </FlexBetween>
                                </Button>
                            </>
                        )}
                    </Box>
                </Box>
            )}
        </>
    )

}

export default Navbar;
