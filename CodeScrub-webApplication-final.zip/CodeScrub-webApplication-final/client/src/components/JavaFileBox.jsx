import React from "react";
import {
    Box,
    Divider,
    useMediaQuery,
} from "@mui/material";
import Text from "./Text";

const JavaFileBox = ({ javaFile }) => {
    const isLargeScreen = useMediaQuery("(min-width:700px)");
    const fileName = Object.keys(javaFile)[0];

    return (
        <Box
            backgroundColor="white"
            borderRadius="10px"
            margin={isLargeScreen ? "30px 0px" : "20px 0px"}
            padding={isLargeScreen ? "2rem 3rem" : "1rem 1.5rem"}
            width="100%"
            boxSizing="border-box"
            overflow="hidden"
        >
            <Text
                textAlign="center"
                fontWeight="bolder"
                fontSize={isLargeScreen ? "1.8rem" : "1.4rem"}
                sx={{
                    wordBreak: "break-word",
                }}
            >
                {fileName}
            </Text>

            <Divider
                sx={{
                    borderBottomWidth: "1.5px",
                    width: isLargeScreen ? "80%" : "90%",
                    marginTop: "1.2rem",
                    marginLeft: "auto",
                    marginRight: "auto",
                }}
            />

            {javaFile[fileName] === "error" ? (
                <Text
                    fontSize={isLargeScreen ? "1.3rem" : "1rem"}
                    margin={isLargeScreen ? "4rem" : "2rem"}
                    sx={{
                        wordBreak: "break-word",
                    }}
                >
                    Some syntax error was found during the parsing of this file.
                </Text>
            ) : (
                <>
                    {Object.keys(javaFile[fileName]).map((item, index) => (
                        <Box
                            key={index}
                            margin={isLargeScreen ? "5rem 0rem" : "3rem 0rem"}
                        >
                            <Text
                                fontWeight="bolder"
                                fontSize={isLargeScreen ? "1.4rem" : "1.2rem"}
                                sx={{
                                    wordBreak: "break-word",
                                }}
                            >
                                {item} :
                            </Text>

                            {item === "File" ? (
                                <Text
                                    fontSize={isLargeScreen ? "1.3rem" : "1rem"}
                                    width="100%"
                                    margin={isLargeScreen ? "30px auto" : "15px auto"}
                                    sx={{
                                        wordBreak: "break-word",
                                    }}
                                >
                                    Overall, the class in this file is a{" "}
                                    <span style={{ color: "red" }}>
                                        {javaFile[fileName][item]}
                                    </span>
                                    .
                                </Text>
                            ) : (
                                <>
                                    <Text
                                        fontSize={isLargeScreen ? "1.3rem" : "1rem"}
                                        width="100%"
                                        margin={isLargeScreen ? "30px auto" : "15px auto"}
                                        sx={{
                                            wordBreak: "break-word",
                                        }}
                                    >
                                        The function contains the following code smells:
                                    </Text>
                                    {javaFile[fileName][item].map((codesmell, number) => (
                                        <Text
                                            fontSize={isLargeScreen ? "1.2rem" : "1rem"}
                                            width="100%"
                                            margin={isLargeScreen ? "30px auto" : "15px auto"}
                                            color="red"
                                            key={`${item}-${number}`}
                                            sx={{
                                                wordBreak: "break-word",
                                            }}
                                        >
                                            <ul>
                                                <li>{codesmell}</li>
                                            </ul>
                                        </Text>
                                    ))}
                                </>
                            )}
                        </Box>
                    ))}
                </>
            )}
        </Box>
    );
};

export default JavaFileBox;
