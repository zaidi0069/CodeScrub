import React from 'react';
import { Box, Button, useMediaQuery } from "@mui/material";
import { MailOutline, GitHub } from "@mui/icons-material";
import { useNavigate } from 'react-router-dom';
import Text from './Text';

const Footer = () => {
    const isLargeScreen = useMediaQuery("(min-width : 1000px)");
    const navigate = useNavigate();
    const codeSmells = {
        javascript: [
            {
                name: "Callback Hell",
                description: "Callback hell refers to the situation in JavaScript where multiple nested callbacks create complex, deeply indented code, often called the “pyramid of doom.”",
                example: `
                   function getUserData(userId, callback) {
                    setTimeout(() => {
                        console.log("Retrieving user data from database...");
                        if (userId === 1) {
                            callback(null, { userId: 1, name: "John Doe", email: "john@example.com" });
                        } else {
                            callback("User not found", null);
                        }
                    }, 1000);
                }

                `,
                solution: "Use async/await or promises",
                solexample: `function getUserData(userId) {
                                return new Promise((resolve, reject) => {
                                    setTimeout(() => {
                                        console.log("Retrieving user data from database...");
                                        if (userId === 1) {
                                            resolve({ userId: 1, name: "John Doe", email: "john@example.com" });
                                        } else {
                                            reject("User not found");
                                        }
                                    }, 1000);
                                });
                            }`
            },

            {
                name: "Improper Error Handling",
                description: "Error handling is not implemented correctly, try catch is not implemented, catch block is empty or does not perform proper error handling leading to unhandled errors.",
                example: `
                   async function logTrustEvaluationResult(url, trustScore) {
                            const response = await fetch("/api/logTrustResult", {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ url, trustScore })
                            });
                            if (!response.ok) throw new Error("Logging failed.");
                            const result = await response.json();
                            return { success: result.success, logId: result.logId };
                        }
                    }
                `,
                solution: "Implement comprehensive error handling with try-catch blocks.",
                solexample: `async function logTrustEvaluationResult(url, trustScore) {
                                try {
                                    const response = await fetch("/api/logTrustResult", {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify({ url, trustScore })
                                    });
                                    if (!response.ok) throw new Error("Logging failed.");
                                    const result = await response.json();
                                    return { success: result.success, logId: result.logId };
                                } catch (error) {
                                    console.error("Error logging trust evaluation result:", error);
                                    return { success: false, message: error.message };
                                }
                            }`
            },


            {
                name: "Long Method",
                description: "A long method code smell occurs when a function or method becomes too long and performs too many tasks.",
                example: `
                        function processOrder(order) {
                            if (!order.product || !order.quantity || !order.price) {
                                console.log("Invalid order data.");
                                return;
                            }

                            let totalPrice = order.quantity * order.price;

                            if (order.quantity > getStock(order.product)) {
                                console.log("Not enough stock available.");
                                return;
                            }

                            const paymentStatus = processPayment(order.paymentDetails, totalPrice);
                            if (!paymentStatus.success) {
                                console.log("Payment failed.");
                                return;
                            }

                            updateStock(order.product, order.quantity);

                            const shippingStatus = shipOrder(order);
                            if (!shippingStatus.success) {
                                console.log("Shipping failed.");
                                return;
                            }

                            console.log("Order processed successfully!");
                        }

                `,
                solution: "Split long methods into smaller, more focused functions.",
                solexample: `function validateOrder(order) {
                                if (!order.product || !order.quantity || !order.price) {
                                    console.log("Invalid order data.");
                                    return false;
                                }
                                return true;
                            }

                            function calculateTotalPrice(order) {
                                return order.quantity * order.price;
                            }
`
            },



            {
                name: "Long Parameter",
                description: "A long parameter list occurs when a function takes too many arguments, which makes the function harder to understand and use. ",
                example:`
                  function createInvoice(items, discount, shippingAddress, billingAddress, paymentMethod, taxRate) {
                        let totalAmount = 0;
                        
                        // Calculate total cost of items
                        items.forEach(item => {
                            totalAmount += item.price * item.quantity;
                        });
                        
                        // Apply discount
                        totalAmount -= discount;
                        
                        // Calculate tax
                        let taxAmount = totalAmount * taxRate;
                        
                        // Calculate final total
                        totalAmount += taxAmount;
                        
                        // Save invoice data
                        saveInvoiceToDatabase(customerName, customerEmail, items, discount, shippingAddress, billingAddress, paymentMethod, totalAmount);
                    }
                    `,
                solution: "Group related parameters into an object.",
                solexample:`
                            const invoiceDetails = {
                            customerName: "John Doe",
                            customerEmail: "john.doe@example.com",
                            items: [{ price: 100, quantity: 2 }, { price: 200, quantity: 1 }],
                            discount: 50,
                            shippingAddress: "123 Main St, Springfield",
                            billingAddress: "123 Main St, Springfield",
                            paymentMethod: "Credit Card",
                            taxRate: 0.08
                        };

                        createInvoice(invoiceDetails);
                        `
            },



            {
                name: "Complex Conditional",
                description: "Conditional statements with multiple conditions, making the code hard to understand.",
                example:`function processOrder(order) {
                            if (order.totalAmount > 100 && order.status === 'pending' || order.customer.isPremium) {
                                if (order.discountApplied) {
                                    console.log("Order will be processed with discount.");
                                } else {
                                    console.log("Processing order without discount.");
                                }
                            } else if (order.totalAmount <= 100 && !order.customer.isPremium) {
                                console.log("Order cannot be processed. Total amount is too low.");
                            } else {
                                console.log("Order is in a different state.");
                            }
                        }
                        `,
                solution: "Extract conditions into separate methods.",
                solexample:`function isOrderEligible(order) {
                                    return order.totalAmount > 100 || order.customer.isPremium;
                                }

                                function processOrder(order) {
                                    if (!isOrderEligible(order)) {
                                        console.log("Order cannot be processed.");
                                        return;
                                    }
                                    
                                    if (order.discountApplied) {
                                        console.log("Order will be processed with discount.");
                                    } else {
                                        console.log("Processing order without discount.");
                                    }
                                }
                                `
            },

            {
                name: "Empty Catch",
                description: "In Empty catch smell, try catch is implemented but the catch block is left empty",
                example:`async function processQuery(userId, query) {
                                try {
                                    const response = await fetch("/api/chatbot/query", {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify({ userId, query })
                                    });
                                    if (!response.ok) throw new Error("Query processing failed: {response.statusText}");
                                    return await response.json();
                                } catch (error) {
                            
                                }
                            }`,
                solution: "Implement proper error handling in catch block",
                solexample:`async function processQuery(userId, query) { 
                                    try {
                                        const response = await fetch("/api/chatbot/query", {
                                            method: 'POST',
                                            headers: { 'Content-Type': 'application/json' },
                                            body: JSON.stringify({ userId, query })
                                        });

                                        if (!response.ok) {
                                            throw new Error("Query processing failed: {response.statusText} (Status code: {response.status})");
                                        }

                                        const data = await response.json();
                                        return data;
                                        
                                    } catch (error) {
                                        console.error('Error occurred while processing the query:', error);

                                        if (error.name === 'TypeError') {
                                            return { error: 'Network error occurred. Please try again later.' };
                                        }

                                        return { error: error.message || 'An unexpected error occurred.' };
                                    }
                                }
                                `
            },
            {
                name: "Strict Operator Smell",
                description: "Improper use of equlaity, not using strict equality where type match is required",
                example:`function applyDiscount(userInput) {
                            const validDiscountCode = 0; // Discount code could be '0' or 0.

                            if (userInput == validDiscountCode) {  // Loose equality allows for type coercion (e.g., '0' == 0)
                                console.log("Discount applied!");
                            } else {
                                console.log("Invalid discount code.");
                            }
                        }
                            `,
                solution: "Use strict equality where type match is also required",
                solexample:`function applyDiscount(userInput) {
                            const validDiscountCode = 0;

                            if (userInput === validDiscountCode) {  // Strict equality (no type coercion)
                                console.log("Discount applied!");
                            } else {
                                console.log("Invalid discount code.");
                            }
                        }
                        `
            }
        ],

        java: [
            {
                name: "Data Class",
                description: "A data class smell refers to the situation where a class is primarily used to hold data without much functionality or behavior. ",
                example:`public class Person {
                            private String name;
                            private int age;

                            public Person(String name, int age) {
                                this.name = name;
                                this.age = age;
                            }

                            public String getName() {
                                return name;
                            }

                            public void setName(String name) {
                                this.name = name;
                            }

                            public int getAge() {
                                return age;
                            }

                            public void setAge(int age) {
                                this.age = age;
                            }
                        }
                        `,
                solution: "Add behavior related to the data to these classes",
                solexample:`public class Person {
                                private String name;
                                private int age;

                                public Person(String name, int age) {
                                    this.name = name;
                                    this.age = age;
                                }

                                public boolean isEligibleForVoting() {
                                    return this.age >= 18;
                                }

                            }
                            `
            },


            {
                name: "Blob/Large Class",
                description: "Large Class Smell refers to a situation where a class becomes too large and does too many things. This is a violation of the Single Responsibility Principle (SRP)",
                example:`public class Car
                            {
                                private string make;
                                private string model;
                                private int year;
                                private string color;
                                private bool isRunning;
                                private bool isParked;

                                public Car(string make, string model, int year, string color)
                                {
                                    this.make = make;
                                    this.model = model;
                                    this.year = year;
                                    this.color = color;
                                    this.isRunning = false;
                                    this.isParked = true;
                                }

                                public void Start()
                                {
                                    if (isParked)
                                    {
                                        isRunning = true;
                                        isParked = false;
                                        Console.WriteLine("The car has started.");
                                    }
                                    else
                                    {
                                        Console.WriteLine("You can't start the car while it's already running or not parked.");
                                    }
                                }

                                public void Stop()
                                {
                                    if (isRunning)
                                    {
                                        isRunning = false;
                                        isParked = true;
                                        Console.WriteLine("The car has stopped.");
                                    }
                                    else
                                    {
                                        Console.WriteLine("You can't stop the car while it's not running or already parked.");
                                    }
                                }

                                public void Accelerate(int speed)
                                {
                                    if (isRunning && !isParked)
                                    {
                                        Console.WriteLine($"The car is accelerating to {speed} mph.");
                                    }
                                    else
                                    {
                                        Console.WriteLine("You can't accelerate while the car is not running or parked.");
                                    }
                                }

                                public void Brake()
                                {
                                    if (isRunning && !isParked)
                                    {
                                        Console.WriteLine("The car is braking.");
                                    }
                                    else
                                    {
                                        Console.WriteLine("You can't brake while the car is not running or parked.");
                                    }
                                }

                                public void Paint(string newColor)
                                {
                                    color = newColor;
                                    Console.WriteLine($"The car has been painted {newColor}.");
                                }

                                public void TuneUp()
                                {
                                    Console.WriteLine("The car has had a tune-up.");
                                }

                              
                            }`,
                solution: "Break down the large class into smaller, more focused classes.",
                solexample:`public class CarActions
                                {
                                    private readonly CarState carState;

                                    public CarActions(CarState carState)
                                    {
                                        this.carState = carState;
                                    }

                                    public void Accelerate(int speed)
                                    {
                                        if (carState.IsRunning && !carState.IsParked)
                                        {
                                            Console.WriteLine($"The car is accelerating to {speed} mph.");
                                        }
                                        else
                                        {
                                            throw new InvalidOperationException("You can't accelerate while the car is not running or parked.");
                                        }
                                    }

                                    public void Brake()
                                    {
                                        if (carState.IsRunning && !carState.IsParked)
                                        {
                                            Console.WriteLine("The car is braking.");
                                        }
                                        else
                                        {
                                            throw new InvalidOperationException("You can't brake while the car is not running or parked.");
                                        }
                                    }
                                }
                                `
            },
            {
                name: "Long Method",
                description: "A long method code smell occurs when a function or method becomes too long and performs too many tasks.",
                example: `
                         function processOrder(order) {
                            if (!order.product || !order.quantity || !order.price) {
                                console.log("Invalid order data.");
                                return;
                            }

                            let totalPrice = order.quantity * order.price;

                            if (order.quantity > getStock(order.product)) {
                                console.log("Not enough stock available.");
                                return;
                            }

                            const paymentStatus = processPayment(order.paymentDetails, totalPrice);
                            if (!paymentStatus.success) {
                                console.log("Payment failed.");
                                return;
                            }

                            updateStock(order.product, order.quantity);

                            const shippingStatus = shipOrder(order);
                            if (!shippingStatus.success) {
                                console.log("Shipping failed.");
                                return;
                            }

                            console.log("Order processed successfully!");
                        }

                `,
                solution: "Split long methods into smaller, more focused functions.",
                solexample: `function validateOrder(order) {
                                if (!order.product || !order.quantity || !order.price) {
                                    console.log("Invalid order data.");
                                    return false;
                                }
                                return true;
                            }

                            function calculateTotalPrice(order) {
                                return order.quantity * order.price;
                            }
`
            },


            {
                name: "Long Parameter",
                description: "A long parameter list occurs when a function takes too many arguments, which makes the function harder to understand and use. ",
                example:`
                  function createInvoice(items, discount, shippingAddress, billingAddress, paymentMethod, taxRate) {
                        let totalAmount = 0;
                        
                        // Calculate total cost of items
                        items.forEach(item => {
                            totalAmount += item.price * item.quantity;
                        });
                        
                        // Apply discount
                        totalAmount -= discount;
                        
                        // Calculate tax
                        let taxAmount = totalAmount * taxRate;
                        
                        // Calculate final total
                        totalAmount += taxAmount;
                        
                        // Save invoice data
                        saveInvoiceToDatabase(customerName, customerEmail, items, discount, shippingAddress, billingAddress, paymentMethod, totalAmount);
                    }
                    `,
                solution: "Group related parameters into an object.",
                solexample:`
                            const invoiceDetails = {
                            customerName: "John Doe",
                            customerEmail: "john.doe@example.com",
                            items: [{ price: 100, quantity: 2 }, { price: 200, quantity: 1 }],
                            discount: 50,
                            shippingAddress: "123 Main St, Springfield",
                            billingAddress: "123 Main St, Springfield",
                            paymentMethod: "Credit Card",
                            taxRate: 0.08
                        };

                        createInvoice(invoiceDetails);
                        `
            },


            {
                name: "Feature Envy",
                description: "Feature Envy is a code smell where a method in one class is overly interested in the details of another class. This typically means that the method is accessing or manipulating data from another object, often more than it needs",
                example:`public class Order {
                            private double price;
                            private Customer customer;

                            public Order(double price, Customer customer) {
                                this.price = price;
                                this.customer = customer;
                            }

                            public double calculateDiscountedPrice() {
                                double discount = customer.getDiscountRate();  // Feature envy: Accessing too much detail from Customer
                                return price * (1 - discount);
                            }
                        }

                        public class Customer {
                            private String name;
                            private String email;
                            private double discountRate;

                            public Customer(String name, String email, double discountRate) {
                                this.name = name;
                                this.email = email;
                                this.discountRate = discountRate;
                            }

                            public double getDiscountRate() {
                                return discountRate;
                            }
                        }
`,
                solution: "Move methods closer to the data they operate on.",
                solexample:`public class Order {
                                private double price;
                                private Customer customer;

                                public Order(double price, Customer customer) {
                                    this.price = price;
                                    this.customer = customer;
                                }

                                public double getTotalPrice() {
                                    return customer.calculateDiscountedPrice(price);  // Delegate calculation to Customer
                                }
                            }

                            public class Customer {
                                private String name;
                                private String email;
                                private double discountRate;

                                public Customer(String name, String email, double discountRate) {
                                    this.name = name;
                                    this.email = email;
                                    this.discountRate = discountRate;
                                }

                                public double calculateDiscountedPrice(double price) {
                                    return price * (1 - discountRate);
                                }
                            }
                            `
            },


            {
                name: "Primitive Obsession",
                description: "Overuse of primitive data types .",
                example:`public class CheckingAccount {
                            public int AccountNumber { get; set; }
                            public string CustomerName { get; set; }
                            public string Email { get; private set; }

                            public string Address { get; set; }
                            public int ZipCode { get; set; }
                            public string City { get; set; }
                            public string State { get; set; }
                            public string Country { get; set; }

                            public string SocialSecurityNumber { get; set; }
                            public DateTime ActiveDate { get; set; }
                            }`,
                solution: "Replace primitives with small objects for domain-specific information.",
                solexample:`public class CheckingAccount
                                {
                                    public AccountNumber AccountNumber { get; private set; }
                                    public CustomerName CustomerName { get; private set; }
                                    public Email Email { get; private set; }
                                    public Address Address { get; private set; }
                                    public SocialSecurityNumber SocialSecurityNumber { get; private set; }
                                    public AccountActivationDate ActiveDate { get; private set; }

                                    public CheckingAccount(AccountNumber accountNumber, CustomerName customerName, Email email, Address address, SocialSecurityNumber socialSecurityNumber, AccountActivationDate activeDate)
                                    {
                                        AccountNumber = accountNumber;
                                        CustomerName = customerName;
                                        Email = email;
                                        Address = address;
                                        SocialSecurityNumber = socialSecurityNumber;
                                        ActiveDate = activeDate;
                                    }
                                }

                                public class AccountNumber
                                {
                                    public int Value { get; private set; }
                                    
                                    public AccountNumber(int value)
                                    {
                                        if (value <= 0) throw new ArgumentException("Account number must be positive.");
                                        Value = value;
                                    }
                                }

                              

                              

                                public class Address
                                {
                                    public string Street { get; private set; }
                                    public string City { get; private set; }
                                    public string State { get; private set; }
                                    public ZipCode ZipCode { get; private set; }
                                    public string Country { get; private set; }

                                    public Address(string street, string city, string state, ZipCode zipCode, string country)
                                    {
                                        Street = street;
                                        City = city;
                                        State = state;
                                        ZipCode = zipCode;
                                        Country = country;
                                    }
                                }

                              

                                public class SocialSecurityNumber
                                {
                                    public string Value { get; private set; }

                                    public SocialSecurityNumber(string value)
                                    {
                                        if (string.IsNullOrWhiteSpace(value) || value.Length != 9) throw new ArgumentException("Invalid Social Security Number.");
                                        Value = value;
                                    }
                                }

                                public class AccountActivationDate
                                {
                                    public DateTime Date { get; private set; }

                                    public AccountActivationDate(DateTime date)
                                    {
                                        if (date > DateTime.Now) throw new ArgumentException("Activation date cannot be in the future.");
                                        Date = date;
                                    }
                                }
                                `
            }
        ]
    };

    const handleNavigate = (smell) => {
        navigate('/smell-info', { state: smell });
    };

    return (
        <Box
            backgroundColor="#1e3d3b"
            padding="60px 10%"
            color="white"
            sx={{
                "& button": {
                    backgroundColor: "#4CAF50",
                    color: "white",
                    borderRadius: "8px",
                    margin: "10px",
                    padding: "10px 20px",
                    transition: "transform 0.3s, background-color 0.3s",
                    "&:hover": {
                        backgroundColor: "#66bb6a",
                        transform: "scale(1.05)",
                    },
                },
            }}
        >
            <Text fontSize="1.2rem" color="yellow" margin="3rem 0" mb="6rem" textAlign="center">
                Code smell scans repositories for the following code smells
            </Text>
            
            <Text fontSize="1.2rem" color="yellow" margin="2rem 0">JavaScript Code Smells</Text>
            {codeSmells.javascript.map((smell) => (
                <Button key={smell.name} onClick={() => handleNavigate(smell)}>
                    {smell.name}
                </Button>
            ))}

            <Text fontSize="1.2rem" color="yellow" mb="2rem" mt="6rem">Java Code Smells</Text>
            {codeSmells.java.map((smell) => (
                <Button key={smell.name} onClick={() => handleNavigate(smell)}>
                    {smell.name}
                </Button>
            ))}
        </Box>
    );
};

export default Footer;
