import { Typography } from "@mui/material";
import { styled } from "@mui/system";

const Text = styled(Typography)({
    fontFamily : "'REM', sans-serif",
    fontSize : "bold"
})

export default Text;