import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Box, Typography, Divider, Button } from '@mui/material';
import Navbar from '../components/Navbar';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';



const SmellInfo = () => {
    const location = useLocation();
    const { name, description, example, solution, solexample } = location.state || {};
    const navigate = useNavigate()

    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    return (
        <>
            <Navbar pageType="smellinfopage" />


            <Box
                sx={{
                    paddingTop: '10vh',
                    paddingBottom: '10vh',
                    backgroundColor: 'slategray',
                    minHeight: '100vh',
                    width: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    boxSizing: 'border-box',
                }}
            >



<Button
                sx={{
                    marginLeft: "2em",
                    marginBottom:"2em",
                    width:"7em",
                    alignItems:"flex-start",
                   
                }}
                variant="contained"
                color="primary"
                startIcon={<ArrowBackIcon />}
                onClick={() => navigate(-1)}
            >
                back
            </Button>


                <Box
                    sx={{
                        backgroundColor: 'rgb(72, 82, 93)',
                        borderRadius: '10px',
                        color: 'white',
                        boxShadow: 3,
                        maxWidth: '900px',
                        width: '90%', // Make the box take up 90% of the viewport width on smaller screens
                        margin: 'auto',
                        padding: {
                            xs: '1rem', // padding for extra-small screens
                            sm: '1.5rem', // padding for small screens
                            md: '2rem', // padding for medium and up
                        },
                        boxSizing: 'border-box',
                    }}
                >
                    <Typography
                        variant="h4"
                        color="whitesmoke"
                        gutterBottom
                        sx={{ textAlign: 'center', fontWeight: 'bold', wordWrap: 'break-word' }}
                    >
                        {name || 'Code Smell Information'}
                    </Typography>
                    <Divider sx={{ backgroundColor: '#ffdd57', marginBottom: '1.5rem' }} />

                    {name ? (
                        <>
                            <Typography variant="body1" paragraph sx={{ fontSize: { xs: '1rem', md: '1.1rem' }, wordWrap: 'break-word' }}>
                                <strong>Description: </strong>{description}
                            </Typography>

                            {example && (
                                <Box
                                    sx={{
                                        backgroundColor: '#333',
                                        padding: '1rem',
                                        borderRadius: '8px',
                                        overflowX: 'auto', // Allow horizontal scrolling for code snippets
                                        marginBottom: '1rem',
                                    }}
                                >
                                    <Typography variant="body2" sx={{ color: '#ffdd57', fontWeight: 'bold' }}>
                                        Example:
                                    </Typography>
                                    <pre
                                        style={{
                                            color: '#f1f1f1',
                                            whiteSpace: 'pre-wrap', // Allow lines to wrap
                                            wordWrap: 'break-word',
                                            margin: 0,
                                        }}
                                    >
                                        {example}
                                    </pre>
                                </Box>
                            )}

                            <Typography variant="body1" paragraph sx={{ fontSize: { xs: '1rem', md: '1.1rem' }, wordWrap: 'break-word' }}>
                                <strong>Solution: </strong>{solution}
                            </Typography>

                            {solution && (
                                <Box
                                    sx={{
                                        marginTop: '2rem',
                                        backgroundColor: '#333',
                                        padding: '1rem',
                                        borderRadius: '8px',
                                        overflowX: 'auto',
                                    }}
                                >
                                    <pre
                                        style={{
                                            color: '#f1f1f1',
                                            whiteSpace: 'pre-wrap',
                                            wordWrap: 'break-word',
                                            margin: 0,
                                        }}
                                    >
                                        {solexample}
                                    </pre>
                                </Box>
                            )}
                        </>
                    ) : (
                        <Typography variant="h6" color="error" align="center">
                            No code smell selected.
                        </Typography>
                    )}
                </Box>
            </Box>
        </>
    );
};

export default SmellInfo;
