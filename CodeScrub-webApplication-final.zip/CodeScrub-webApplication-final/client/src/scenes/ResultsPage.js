import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import Navbar from "../components/Navbar";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import DownloadIcon from '@mui/icons-material/Download';
import { Box, Button, useMediaQuery } from "@mui/material";
import Text from "../components/Text";
import JavaFileBox from "../components/JavaFileBox";
import JavascriptFileBox from "../components/JavascriptFileBox";
import { useNavigate } from "react-router-dom";
import jsPDF from "jspdf";

const ResultsPage = () => {
    const isLargeScreen = useMediaQuery("(min-width:700px)");
    const repository = useSelector(state => state.repository);
    const branch = useSelector(state => state.branch);
    const scannedResult = useSelector(state => state.scannedResult);
    const navigate = useNavigate();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    const handleDownloadPDF = () => {
        const pdf = new jsPDF();
    
        // Page margins and positions
        let yPosition = 30; // Start a bit down from the top for title
        let pageno = 1;
        const pageWidth = pdf.internal.pageSize.getWidth();
        const leftMargin = 15;
        const rightMargin = 15;
        const usableWidth = pageWidth - (leftMargin + rightMargin);
        const bottomMargin = 280; // leave some space at the bottom
    
        const addHeader = () => {
            pdf.setFont('helvetica', 'normal');
            pdf.setFontSize(8);
            pdf.setTextColor("#888");
            pdf.text(`Repository: ${repository || 'N/A'} | Page: ${pageno}`, leftMargin, 10);
        };
    
        const addTitle = () => {
            pdf.setFont('helvetica', 'bold');
            pdf.setFontSize(20);
            pdf.setTextColor("#000");
            const title = 'Code Smell Report';
            const titleWidth = pdf.getTextWidth(title);
            const titleX = (pageWidth - titleWidth) / 2;
            pdf.text(title, titleX, yPosition);
            yPosition += 10;
        };
    
        const addDate = () => {
            pdf.setFontSize(10);
            pdf.setTextColor("#555");
            const currentDate = new Date().toLocaleString();
            pdf.text(`Date: ${currentDate}`, leftMargin, yPosition);
            yPosition += 10;
        };
    
        const addRepoInfo = () => {
            pdf.setFontSize(12);
            pdf.setTextColor("#333");
            pdf.setFont('helvetica', 'bold');
            pdf.text(`Repository: `, leftMargin, yPosition);
            pdf.setFont('helvetica', 'normal');
            pdf.text(`${repository || 'N/A'}`, leftMargin + 28, yPosition); 
            yPosition += 6;
    
            pdf.setFont('helvetica', 'bold');
            pdf.text(`Branch: `, leftMargin, yPosition);
            pdf.setFont('helvetica', 'normal');
            pdf.text(`${branch || 'N/A'}`, leftMargin + 20, yPosition);
            yPosition += 10;
        };
    
        const addSectionTitle = (text) => {
            pdf.setFontSize(14);
            pdf.setFont('helvetica', 'bold');
            pdf.setTextColor("#00796b");
            pdf.text(text, leftMargin, yPosition);
            yPosition += 10;
        };
    
        const checkPageAdd = () => {
            if (yPosition > bottomMargin) {
                pdf.addPage();
                pageno++;
                addHeader();
                yPosition = 20; // restart from top margin on new page
            }
        };
    
        // Initial page setup
        addHeader();
        addTitle();
        addDate();
        addRepoInfo();
        addSectionTitle('Scanned Results:');
    
        if (!scannedResult) {
            pdf.setFontSize(12);
            pdf.setFont('helvetica', 'normal');
            pdf.setTextColor("#555");
            pdf.text('No previously scanned repository.', leftMargin, yPosition);
        } else if (scannedResult === 'empty') {
            pdf.setFontSize(12);
            pdf.setFont('helvetica', 'normal');
            pdf.setTextColor("#555");
            pdf.text('Scan result for this repository is empty!', leftMargin, yPosition);
        } else {
            pdf.setFont('helvetica', 'normal');
            Object.keys(scannedResult).forEach((file) => {
                checkPageAdd();
                pdf.setFontSize(12);
                pdf.setTextColor("#00796b");
                pdf.setFont('helvetica', 'bold');
                pdf.text(`File: ${file}`, leftMargin, yPosition);
                yPosition += 7;
    
                const codeSmells = scannedResult[file];
    
                if (typeof codeSmells === 'object' && Object.keys(codeSmells).length > 0) {
                    const innerKeys = Object.keys(codeSmells);
                    const isNumericKeys = innerKeys.every(k => /^\d+$/.test(k));
    
                    innerKeys.forEach((smellKey) => {
                        checkPageAdd();
    
                        const smellValue = codeSmells[smellKey];
    
                        if (isNumericKeys) {
                            // Numeric keys: [codeSnippet, smell1, smell2, ...]
                            if (Array.isArray(smellValue)) {
                                const codeSnippet = smellValue.length > 0 ? smellValue[0] : 'No Code Available';
    
                                // Print code snippet
                                pdf.setFontSize(10);
                                pdf.setFont('helvetica', 'normal');
                                pdf.setTextColor("rgb(0,0,0)");
    
                                const lines = pdf.splitTextToSize(codeSnippet, usableWidth);
                                lines.forEach((line) => {
                                    checkPageAdd();
                                    pdf.text(line, leftMargin + 5, yPosition);
                                    yPosition += 6;
                                });
    
                                // Print the smells
                                for (let i = 1; i < smellValue.length; i++) {
                                    checkPageAdd();
                                    const smellName = smellValue[i];
                                    pdf.setFontSize(12);
                                    pdf.setFont('helvetica', 'bold');
                                    pdf.setTextColor("rgb(126, 0, 0)");
                                    pdf.text(`• ${smellName}`, leftMargin + 10, yPosition);
                                    yPosition += 10;
                                }
                            } else {
                                // Unexpected scenario
                                pdf.setFontSize(10);
                                pdf.setFont('helvetica', 'italic');
                                pdf.setTextColor("#333");
                                pdf.text(`Non-array value encountered at key: ${smellKey}`, leftMargin + 5, yPosition);
                                yPosition += 10;
                            }
    
                        } else {
                            // Non-numeric keys (function names or 'File')
                            if (smellKey === "File") {
                                if (typeof smellValue === 'string') {
                                    pdf.setFontSize(10);
                                    pdf.setFont('helvetica', 'italic');
                                    pdf.setTextColor("rgb(0,0,0)");
                                    pdf.text(`File Info: ${smellValue}`, leftMargin + 5, yPosition);
                                    yPosition += 10;
                                } else {
                                    pdf.setFontSize(10);
                                    pdf.setFont('helvetica', 'italic');
                                    pdf.setTextColor("#333");
                                    pdf.text(`Expected a string for 'File' key, got something else.`, leftMargin + 5, yPosition);
                                    yPosition += 10;
                                }
    
                            } else {
                                // Function names with arrays of smells
                                if (Array.isArray(smellValue)) {
                                    if (smellValue.length === 0) {
                                        pdf.setFontSize(10);
                                        pdf.setFont('helvetica', 'normal');
                                        pdf.setTextColor("#333");
                                        pdf.text('No Code Smells detected.', leftMargin + 5, yPosition);
                                        yPosition += 10;
                                    } else {
                                        // Function name as a heading
                                        pdf.setFontSize(11);
                                        pdf.setFont('helvetica', 'bold');
                                        pdf.setTextColor("#00796b");
                                        pdf.text(`Function: ${smellKey}`, leftMargin + 5, yPosition);
                                        yPosition += 7;
    
                                        smellValue.forEach((smellName) => {
                                            checkPageAdd();
                                            pdf.setFontSize(12);
                                            pdf.setFont('helvetica', 'bold');
                                            pdf.setTextColor("rgb(126, 0, 0)");
                                            pdf.text(`• ${smellName}`, leftMargin + 10, yPosition);
                                            yPosition += 10;
                                        });
                                    }
                                } else {
                                    pdf.setFontSize(10);
                                    pdf.setFont('helvetica', 'italic');
                                    pdf.setTextColor("#333");
                                    pdf.text(`Expected an array of smells for '${smellKey}', got a ${typeof smellValue}`, leftMargin + 5, yPosition);
                                    yPosition += 10;
                                }
                            }
                        }
    
                        yPosition += 5;
                    });
                } else {
                    pdf.setFontSize(10);
                    pdf.setFont('helvetica', 'normal');
                    pdf.setTextColor("#333");
                    pdf.text('No Code Smells detected in this file.', leftMargin + 5, yPosition);
                    yPosition += 10;
                }
    
                // Add a divider line after each file section for visual separation
                pdf.setDrawColor(200, 200, 200);
                pdf.line(leftMargin, yPosition, pageWidth - rightMargin, yPosition);
                yPosition += 10;
            });
        }
    
        pdf.save(`Report - ${repository}.pdf`);
    };
    
    

    return (
        <>
            <Navbar pageType="dashboard" />
            <Box display="flex" justifyContent="space-between" mb="1rem">
                <Button
                    variant="contained"
                    color="primary"
                    style={{ margin: "0.5em 0 0 0.5em " }}
                    startIcon={<ArrowBackIcon />}
                    onClick={() => navigate(-1)}
                >
                    Back
                </Button>

                <Button
                    variant="contained"
                    color="success"
                    style={{ margin: "0.5em 0.5em 0 0" }}
                    startIcon={<DownloadIcon />}
                    onClick={handleDownloadPDF}
                >
                    Download PDF
                </Button>
            </Box>

            {!Boolean(scannedResult) ? (
                <Box
                    height={isLargeScreen ? "85vh" : "auto"}
                    backgroundColor="#E3F0EE"
                    padding={isLargeScreen ? "5rem" : "2rem"}
                >
                    <Text 
                        textAlign="center" 
                        fontWeight="500" 
                        fontSize={isLargeScreen ? "1.5rem" : "1.2rem"}
                    >
                        No previously Scanned Repository 
                    </Text>
                </Box>
            ) : (
                <Box
                    backgroundColor="#E3F0EE"
                    padding={isLargeScreen ? "0.5rem 3rem" : "0.5rem 1rem"}
                    minHeight={isLargeScreen ? "85vh" : "auto"}
                >
                    <Box
                        display="flex"
                        flexDirection={isLargeScreen ? "row" : "column"}
                        alignItems={isLargeScreen ? "center" : "flex-start"}
                        gap="30px"
                        width={isLargeScreen ? "50%" : "100%"}
                        margin="1.5rem auto"
                    >
                        <Text 
                            fontWeight="bolder" 
                            fontSize={isLargeScreen ? "1.95rem" : "1.2rem"}
                        >
                            Repository: 
                        </Text>
                        <Text 
                            fontSize={isLargeScreen ? "1.75rem" : "1.2rem"}
                        >
                            {repository} 
                        </Text>
                    </Box>   

                    <Box
                        display="flex"
                        flexDirection={isLargeScreen ? "row" : "column"}
                        alignItems={isLargeScreen ? "center" : "flex-start"}
                        width={isLargeScreen ? "50%" : "100%"}
                        gap="30px"
                        margin="1rem auto"
                        mb="5rem"
                    >
                        <Text 
                            fontWeight="bolder" 
                            fontSize={isLargeScreen ? "1.95rem" : "1.2rem"}
                        >
                            Branch: 
                        </Text>
                        <Text 
                            fontSize={isLargeScreen ? "1.75rem" : "1.2rem"}
                        >
                            {branch} 
                        </Text>
                    </Box>

                    { Object.keys(scannedResult)[0] === "repository" && scannedResult[Object.keys(scannedResult)[0]] === "clean" ? (
                        <Text 
                            textAlign="center" 
                            fontWeight="500" 
                            fontSize={isLargeScreen ? "1.5rem" : "1.2rem"}
                        >
                            Repository is Clean. No Code Smells found.
                        </Text>
                    ) : (
                        <>
                            {Object.keys(scannedResult).map((item, index) => {
                                const fileObject = {};
                                fileObject[item] = scannedResult[item];
                                return(
                                    <Box key={index}>
                                        {item.includes(".java") ? (
                                            <JavaFileBox javaFile={fileObject}/>
                                        ) : (
                                            <JavascriptFileBox javascriptFile={fileObject}/>
                                        )}
                                    </Box>
                                )
                            })}
                        </>
                    )}   

                </Box>
            )}
        </>
    );
};

export default ResultsPage;
