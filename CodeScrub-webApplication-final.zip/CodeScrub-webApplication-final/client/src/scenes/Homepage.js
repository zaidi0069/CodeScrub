import React from "react";
import {
    Box,
    useMediaQuery,
    Button,
} from "@mui/material";
import {
    GitHub,
    Input
} from "@mui/icons-material";
import { useRef } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBitbucket, faSquareGitlab } from "@fortawesome/free-brands-svg-icons";
import FlexBetween from "../components/FlexBetween";
import Text from "../components/Text";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import 'animate.css';
import Typewriter from 'typewriter-effect';

const Homepage = () => {

    const isLargeScreen = useMediaQuery("(min-width : 1000px)");
    const getStartedRef = useRef(null);

    // function for forwarding users to github authentication login page
    const forwardToGithubLogin = () => {
        window.location.assign(`https://github.com/login/oauth/authorize?client_id=${process.env.REACT_APP_CLIENT_ID}&scope=user%20repo&login`);
    }

    // function for forwarding users to gitlab authentication login page
    const forwardToGitlabLogin = () => {
        window.location.assign(`https://gitlab.com/oauth/authorize?client_id=${process.env.REACT_APP_GITLAB_CLIENT_ID}&redirect_uri=${"http://15.206.242.87:3000/dashboard/gitlab"}&response_type=code&scope=api+read_api+read_user+read_repository`);
    }

    // function for forwarding users to bitbucket authentication login page
    const forwardToBitbucketLogin = () => {
        
        window.location.assign(`https://bitbucket.org/site/oauth2/authorize?client_id=${process.env.REACT_APP_BITBUCKET_CLIENT_ID}&response_type=code`);
    }

    return (
        <>
            {/* Navbar */}
            <Navbar pageType="homepage" getStartedRef={getStartedRef} />

            {/* Description Box */}
            <Box
                display="flex"
                flexDirection={isLargeScreen ? "row" : "column"}
                alignItems="center"
                justifyContent="space-evenly"
                padding={isLargeScreen ? "5.5rem 0rem" : "5.5rem 6%"}
            >
                <Box width={isLargeScreen ? "50%" : "100%"}>
                    <Text sx={{ fontFamily: "Kanit, sans-serif", fontWeight: "800", fontSize: "3rem", textAlign: "center" }}>
                        Code Scrub
                    </Text>
                    <Text sx={{ fontFamily: "Kanit, sans-serif", fontWeight: "500", fontSize: isLargeScreen ? "2rem" : "1.8rem", textAlign: "center", marginTop: "20px" }}>
                        AI Powered Developers' Assistant
                    </Text>


                    <Text textAlign={"center"} fontWeight="700" marginTop={isLargeScreen ? "30px" : "50px"} fontSize="1.2rem" color="red">
                        <Typewriter options={{
                            strings: ["Tired of debugging? ",
                                " Let AI do the heavy lifting... ",
                                "Scan. Detect. Improve.  ",
                                "   CodeScrub: Perfecting your code with precision."
                            ],
                            autoStart: true,
                            loop: true,
                        }}
                            onInit={(typewriter) => {
                                typewriter.typeString()
                                    .callFunction(() => {
                                      
                                    })
                                    .pauseFor(1500)
                                    .deleteAll()
                                    .callFunction(() => {
                                       
                                    })
                                    .start();
                            }}
                        />
                    </Text>

                    <Text
                        fontWeight="500"
                        marginTop={isLargeScreen ? "30px" : "50px"}
                        fontSize="1.2rem"
                    >
                        Discover CodeScrub – your AI-powered code analyzer for JavaScript and Java projects.
                        Effortlessly scan your repository for code smells and poor practices that compromise quality and maintainability.
                        Improve your development process, boost code quality, and save time with CodeScrub’s smart insights.
                        Enjoy a user-friendly interface that lets you analyze your code with just a few clicks, making manual reviews a thing of the past.
                    </Text>
                </Box>
                <Box className={isLargeScreen ? "animate__animated animate__bounceInDown" : ""} width={isLargeScreen ? "30%" : "100%"} marginTop={isLargeScreen ? "0px" : "120px"} paddingTop={isLargeScreen && "3.5rem"}>
                    <img src="image.png" alt="img" style={{ height: "100%", width: "100%", objectFit: "cover" }} />
                </Box>
            </Box>

            {/* Getting Started Box */}
            <Box style={{ background: "linear-gradient(to top left , #E0B0FF, #CCCCFF)", padding: "100px 0px", position: "relative" }}>
                <Box width={isLargeScreen ? "65.5%" : "56%"} margin="0px auto" display="flex" alignItems="center" gap="20px" color="white" marginBottom="30px">
                    <Text fontSize="2rem" sx={{ fontFamily: "Kanit, sans-serif", fontWeight: "500" }} ref={getStartedRef}>
                        Get Started
                    </Text>
                    <Input sx={{ fontSize: "35px" }} />
                </Box>
                <Text width="65%" margin="auto" marginBottom="50px" color="white">
                    Feel free to login with any of the following platforms and provide us your repository containing MERN and JavaScript code. Our system uses authentication mechanisms as provided by these platforms, and your credentials are not received by our system.
                </Text>
                <Box width="75%" margin="0px auto" display="flex" alignItems="center" justifyContent="space-evenly" flexDirection={isLargeScreen ? "row" : "column"} gap={isLargeScreen ? "0px" : "20px"}>
                    <Button sx={{ backgroundColor: "black", width: isLargeScreen ? "25%" : "80%", height: "13vh" }} onClick={forwardToGithubLogin}>
                        <FlexBetween gap="10px">
                            <GitHub sx={{ color: "white", fontSize: "32px" }} />
                            <Text color="white" fontSize="1.3rem"> GitHub </Text>
                        </FlexBetween>
                    </Button>
                    <Button sx={{ color: "white", backgroundColor: "#FF5733", width: isLargeScreen ? "25%" : "80%", height: "13vh" }} onClick={forwardToGitlabLogin}>
                        <FlexBetween gap="10px">
                            <FontAwesomeIcon icon={faSquareGitlab} color="white" fontSize="32px" />
                            <Text color="white" fontSize="1.3rem"> GitLab </Text>
                        </FlexBetween>
                    </Button>
                    <Button sx={{ backgroundColor: "#6495ED", width: isLargeScreen ? "25%" : "80%", height: "13vh" }} onClick={forwardToBitbucketLogin}>
                        <FlexBetween gap="10px">
                            <FontAwesomeIcon icon={faBitbucket} color="white" fontSize="32px" />
                            <Text color="white" fontSize="1.3rem"> BitBucket </Text>
                        </FlexBetween>
                    </Button>
                </Box>

                <Box position="absolute" top="0" left="0" width="100%" overflow="hidden" lineHeight="0" color="red">
                    <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
                        <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" style={{ fill: "white" }}></path>
                    </svg>
                </Box>
            </Box>

            {/* Footer */}
            <Footer />
        </>
    );
};

export default Homepage;
