import React from "react";
import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useParams, useNavigate } from "react-router-dom";
import {
    CircularProgress,
    Box, Button,
    useMediaQuery
} from "@mui/material";
import { setLogout } from "../reduxState";
import Navbar from "../components/Navbar";
import Text from "../components/Text";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

const File = () => {

    const isLargeScreen = useMediaQuery("(min-width : 700px)");
    const [file, setFile] = useState(null);
    const [fileContent, setFileContent] = useState("");
    const [contentsFetched, setContentsFetched] = useState(false);
    const { reponame, branch } = useParams();
    const dir = useParams()["*"];
    const token = useSelector(state => state.token);
    const authTokenType = useSelector(state => state.authTokenType);
    const gitProfile = useSelector(state => state.gitProfile);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const fetchFile = async () => {
        try {
            if (authTokenType === "github")
                var url = `https://api.github.com/repos/${gitProfile.login}/${reponame}/contents/${dir}?ref=${branch}`;
            else if (authTokenType === "gitlab")
                var url = `https://gitlab.com/api/v4/projects/${reponame.replace(/\//g, "%2F")}/repository/files/${dir.replace(/\//g, "%2F")}?ref=${branch}`;
            else
                var url = `https://api.bitbucket.org/2.0/repositories/${reponame.replace(/%2f/g, '/')}/src/${branch}/${dir}`;


            const response = await fetch(url, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            });
            if (authTokenType !== "bitbucket")
                var res = await response.json();
            else
                var res = await response.text();

            if (response.status === 401) {
                dispatch(setLogout());
                navigate("/");
            }
            else if (response.status === 404) {
                alert("not found");
                navigate("/");
            }
            else {
                if (authTokenType !== "bitbucket") {
                    setFile(res);
                    setFileContent(atob(res.content));
                }
                else
                    setFile(res);

                setContentsFetched(true);
            }
        }
        catch (error) {
            alert("Error in getting file");
        }
    }

    useEffect(() => {
        fetchFile();
    }, [])

    return (
        <>
            {Boolean(contentsFetched) ? (
                <>
                
                    <Navbar pageType="dashboard" />
                    <Button 
                                sx={{
                                    margin: isLargeScreen ? "2em" : "1em",

                                }}
                                variant="contained"
                                color="primary"
                                startIcon={<ArrowBackIcon />}
                                onClick={() => navigate(-1)}
                            >
                                back
                            </Button>
                    <Box
                        padding={isLargeScreen ? "4rem" : "3rem 1.3rem"}
                        backgroundColor="#E3F0EE"
                        margin={isLargeScreen ? "3rem 2rem" : "4rem 1rem"}
                    >
                        <Box
                            overflow="auto"
                        >
                         
                            <pre>
                                <Text fontSize={!isLargeScreen && "0.5rem"}>
                                    {authTokenType === "bitbucket" ? file : fileContent}
                                </Text>
                            </pre>
                        </Box>
                    </Box>
                </>
            ) : (
                <>
                    <Box
                        height="100vh"
                        width="100%"
                        display="flex"
                        justifyContent="center"
                        alignItems="center"
                    >
                        <CircularProgress
                            color="secondary"
                            size="4rem"
                        />
                    </Box>
                </>
            )}
        </>
    )
}

export default File;