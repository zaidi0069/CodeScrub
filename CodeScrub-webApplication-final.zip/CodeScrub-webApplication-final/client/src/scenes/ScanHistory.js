import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { setScannedResult } from "../reduxState";
import { useNavigate } from "react-router-dom";
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { IconButton } from "@mui/material";
import DeleteIcon from '@mui/icons-material/Delete';

const ScanHistory = () => {
    const gitProfile = useSelector(state => state.gitProfile);
    const [scanResults, setScanResults] = useState([]);
    const [expandedTile, setExpandedTile] = useState(null);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    const dispatch = useDispatch();

    // Fetch scan results from the backend
    useEffect(() => {
        window.scrollTo(0, 0);
        const fetchScanResults = async () => {
            try {
                const response = await fetch(`${process.env.REACT_APP_BACKEND_BASEURL}/auth/getscanhistory`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        web_url: gitProfile.web_url
                    })
                });
                const data = await response.json();
                setScanResults(data);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching scan results:", error);
            }
        };

        fetchScanResults();
    }, [gitProfile.web_url]);

    const toggleTile = (index) => {
        setExpandedTile(expandedTile === index ? null : index);

        if (expandedTile !== index) {
            dispatch(
                setScannedResult({
                    repository: scanResults[index].repository,
                    branch: scanResults[index].branch,
                    scannedResult: scanResults[index].results ? scanResults[index].results : "empty",
                })
            );

            navigate("/resultspage");
        }
    };


    const handleDelete = (index, generatedAt) => {
        const updatedScanResults = scanResults.filter((result, idx) => idx !== index);
        setScanResults(updatedScanResults);


       const result= fetch(`${process.env.REACT_APP_BACKEND_BASEURL}/auth/deletescannedresult`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                web_url: gitProfile.web_url,
                generatedAt
            })
        });

       
    };




    if (loading) {
        return <p style={{ textAlign: "center", fontSize: "18px", color: "#555", marginTop: "50px" }}>Loading scan results...</p>;
    }

    if (!loading && scanResults.length === 0) {
        setTimeout(() => {
            navigate(-1);
        }, 1000);
    }

    return (
        scanResults && scanResults.length > 0 ? (
            <>
                <Navbar />
                <div style={styles.container}>
                    <h1 style={styles.title}>Scan Results</h1>
                    <div style={styles.tilesContainer}>
                        {scanResults.map((result, index) => (
                            <div
                                key={index}
                                style={styles.tile(expandedTile === index)}
                                onClick={() => toggleTile(index)}
                            >
                                <div style={styles.tileHeader}>
                                    <div style={{display:"flex", justifyContent:"space-between"}}>
                                        <h3 style={styles.tileHeaderTitle}>Scan {index + 1} : {result.repository}</h3>
                                        <IconButton onClick={(e) => {
                                            e.stopPropagation();  // Prevent triggering toggleTile
                                            handleDelete(index, result.generatedAt);
                                        }} aria-label="delete">
                                            <DeleteIcon />
                                        </IconButton>
                                    </div>
                                    <p style={styles.tileHeaderDate}>
                                        Generated At: {new Date(result.generatedAt).toLocaleString()}
                                    </p>
                           



                                </div>
                                {expandedTile === index && (
                                    <div style={styles.tileContent}>
                                        <h4 style={styles.resultsTitle}>Results:</h4>
                                        <ul style={styles.list}>
                                            {Object.keys(result.results).map((file, i) => (
                                                <li key={i} style={styles.listItem}>
                                                    <strong>{file}:</strong>{" "}
                                                    {typeof result.results[file] === "string"
                                                        ? result.results[file]
                                                        : JSON.stringify(result.results[file], null, 2)}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
                <Footer />
            </>
        ) : (
            <div style={styles.noResultsContainer}>
                <h2 style={styles.noResultsText}>No scan results available.</h2>
            </div>
        )
    );
};

export default ScanHistory;

// Inline Styles Update
const styles = {
    container: {
        padding: "10px",
        fontFamily: "Arial, sans-serif",
        backgroundColor: "#f8f9fa",
        minHeight: "70vh",
    },
    title: {
        textAlign: "center",
        fontSize: "36px",
        color: "#333",
        marginBottom: "20px",
        fontWeight: "bold",
    },
    tilesContainer: {
        display: "flex",
        flexWrap: "wrap",
        gap: "20px",
        justifyContent: "center",
    },
    tile: (isExpanded) => ({
        backgroundColor: isExpanded ? "#e0f7fa" : "#ffffff",
        border: "1px solid #ddd",
        borderRadius: "10px",
        padding: "20px",
        width: isExpanded ? "80%" : "350px",
        cursor: "pointer",
        transition: "all 0.3s ease",
        boxShadow: isExpanded ? "0 4px 10px rgba(0, 0, 0, 0.1)" : "0 2px 5px rgba(0, 0, 0, 0.1)",
    }),
    tileHeader: {
        marginBottom: "10px",
      
    },
    tileHeaderTitle: {
        margin: 0,
        fontSize: "20px",
        color: "#00796b",
    },
    tileHeaderDate: {
        margin: "5px 0 0",
        color: "#555",
        fontSize: "14px",
    },
    tileContent: {
        marginTop: "10px",
        fontSize: "14px",
    },
    resultsTitle: {
        fontSize: "18px",
        color: "#00796b",
        marginBottom: "10px",
    },
    list: {
        listStyle: "none",
        padding: 0,
    },
    listItem: {
        marginBottom: "8px",
        fontSize: "14px",
        color: "#333",
    },
   
    noResultsContainer: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "70vh",
        backgroundColor: "rgb(255, 255, 255)",
    },
    noResultsText: {
        fontSize: "2em",
        color: "#00796b",
        fontStyle: "bold",
        background: "rgb(255, 255, 255)",
        padding: "10px 20px",
        borderRadius: "10px",
    },
};
