import React from "react";
import { useState, useEffect } from "react";
import {
    useMediaQuery,
    Table,
    TableBody,
    TableHead,
    TableRow,
    TableCell,
    Box,
    Paper,
    TableContainer,
    Button,
    CircularProgress, 
} from "@mui/material";
import {
    Folder,
    InsertDriveFileOutlined,
    PriorityHigh
} from "@mui/icons-material";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useNavigate, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { setLogout } from "../reduxState";
import Navbar from "../components/Navbar";
import Text from "../components/Text";
import FlexBetween from "../components/FlexBetween";
import Footer from "../components/Footer";

const RepositoryTree = () => {

    const isLargeScreen = useMediaQuery("(min-width : 700px)");
    const [repoContents, setRepoContents] = useState(null);
    const [bitbucketbranchhash, setHash] = useState("");
    const { reponame, branch } = useParams();
    const dir = useParams()["*"];
    const token = useSelector(state => state.token);
    const authTokenType = useSelector(state => state.authTokenType);
    const gitProfile = useSelector(state => state.gitProfile);
    const scannedResult = useSelector(state => state.scannedResult);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const fetchRepositoryContents = async () => {
        try {
            if (authTokenType === "github") {
                if (dir)
                    var url = `https://api.github.com/repos/${gitProfile.login}/${reponame}/contents${dir}?ref=${branch}`;
                else
                    var url = `https://api.github.com/repos/${gitProfile.login}/${reponame}/contents?ref=${branch}`;
            }
            else if (authTokenType === "gitlab") {
                const modifiedRepoName = reponame.replace(/\//g, "%2F");
                var url = `https://gitlab.com/api/v4/projects/${modifiedRepoName}/repository/tree?path=${dir}&ref=${branch}`;
            }
            else {
                const modified = reponame.replace(/%2f/g, '/');
                if (bitbucketbranchhash === "") {
                    let response = await fetch(`https://api.bitbucket.org/2.0/repositories/${modified}/refs/branches/${branch}`, {
                        method: "GET",
                        headers: {
                            "Authorization": `Bearer ${token}`
                        }
                    })
                    let res = await response.json();
                    if (response.status === 200) {
                        setHash(res.target.hash);
                        var v = res.target.hash;
                    }

                    else if (response.status === 401) {
                        dispatch(setLogout());
                        navigate("/");
                    }

                    else
                        navigate("/");
                }
                const branchHash = Boolean(bitbucketbranchhash) ? bitbucketbranchhash : v;
                var url = `https://api.bitbucket.org/2.0/repositories/${modified}/src/${branchHash}/${dir}`
            }
            const response = await fetch(url, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            });
            const res = await response.json();

            if (response.status === 401) {
                dispatch(setLogout());
                navigate("/");
            }
            else if (response.status === 404) {
                alert("Content not found");
                navigate(`/dashboard/${authTokenType}`);
            }
            else
                setRepoContents(res);

        }
        catch (error) {
            alert("Error in getting repository contents");
        }
    }

    const tableClickHandler = (item) => {
        if (authTokenType === "bitbucket") {
            var dirparam = item.path;
        }
        else {
            if (dir)
                var dirparam = dir + "/" + item.name;
            else
                var dirparam = item.name;
        }


        if (item.type === "dir")
            navigate(`/tree/${reponame}/${branch}/${dirparam}`);

        else if (item.type === "file")
            navigate(`/file/${reponame}/${branch}/${dirparam}`);

        else if (item.type === "tree")
            navigate(`/tree/${reponame.replace(/\//g, "%2F")}/${branch}/${dirparam}`);

        else if (item.type === "blob")
            navigate(`/file/${reponame.replace(/\//g, "%2F")}/${branch}/${dirparam}`);

        else if (item.type === "commit_directory")
            navigate(`/tree/${reponame.replace(/\//g, "%2F")}/${branch}/${dirparam}`);

        else if (item.type === "commit_file")
            navigate(`/file/${reponame.replace(/\//g, "%2F")}/${bitbucketbranchhash}/${dirparam}`);
    }

    const checkPresenceInScannedResult = (itemName) => {
        const keys = Object.keys(scannedResult);
        const completePath = Boolean(dir) ? dir + "/" + itemName : itemName;
        for (var i = 0; i < keys.length; i++) {
            if (keys[i].startsWith(completePath))
                return true;
        }
        return false;
    }


    useEffect(() => {
        setRepoContents(null);
        setTimeout(() => { fetchRepositoryContents() }, 300);
    }, [dir]);

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [])


    return (
        <>
            <Navbar pageType="dashboard" />

            <Box pt="5rem" pl="6%" pr="6%">
                <Text textAlign="center" fontWeight="1000" fontSize={isLargeScreen ? "2rem" : "1.5rem"} sx={{ wordBreak: !isLargeScreen && "break-all" }}>
                    {`${reponame}/${branch}/${dir}`}
                </Text>
            </Box>

            {Boolean(repoContents) ? (
                <Box
                    padding={isLargeScreen ? "4rem" : "4rem 3%"}
                >
                     <Button
                        sx={{
                            marginRight: isLargeScreen ? "20em" : "2em",
                            marginBottom:"5px"

                        }}
                        variant="contained"
                        color="primary"
                        startIcon={<ArrowBackIcon />}
                        onClick={() => navigate(-1)}
                    >
                        back
                    </Button>
                 
                    <TableContainer component={Paper}>
                        <Table>
                            <TableHead sx={{ backgroundColor: "#00b894" }}>
                                <TableRow sx={{ "&>th": { color: "white" } }}>
                                    <TableCell> <Text> No.</Text> </TableCell>
                                    <TableCell> <Text> Name </Text> </TableCell>
                                    <TableCell> <Text> Type </Text> </TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {Boolean(repoContents) && (authTokenType !== "bitbucket" ? repoContents.map((item, index) => {
                                    return (
                                        <>
                                            <TableRow key={item.url}>
                                                <TableCell> <Text> {index + 1} </Text> </TableCell>
                                                <TableCell>
                                                    <Box display="flex" alignItems="center"
                                                        sx={{ "&:hover": { cursor: "pointer" } }}
                                                        onClick={() => { tableClickHandler(item) }}
                                                    >
                                                        {(item.type === "dir" || item.type === "tree") ? (<Folder sx={{ color: "blue", width: "5%" }} />) : (<InsertDriveFileOutlined sx={{ "&:hover": { cursor: "pointer" }, width: "5%" }} />)}
                                                        <FlexBetween width="95%" paddingLeft="5%">
                                                            <Text
                                                                sx={{ "&:hover": { color: "blue", textDecoration: "underline" } }}
                                                            >
                                                                {item.name}
                                                            </Text>
                                                            {checkPresenceInScannedResult(item.name) && (
                                                                <PriorityHigh sx={{ color: "red" }} />
                                                            )}
                                                        </FlexBetween>
                                                    </Box>
                                                </TableCell>
                                                <TableCell> <Text> {item.type} </Text> </TableCell>
                                            </TableRow>
                                        </>
                                    )
                                }) : repoContents.values.map((item, index) => {
                                    return (
                                        <>
                                            <TableRow key={item.url}>
                                                <TableCell> <Text> {index + 1} </Text> </TableCell>
                                                <TableCell>
                                                    <Box display="flex" alignItems="center"
                                                        sx={{ "&:hover": { cursor: "pointer" } }}
                                                        onClick={() => { tableClickHandler(item) }}
                                                    >
                                                        {item.type === "commit_directory" ? (<Folder sx={{ color: "blue", width: "5%" }} />) : (<InsertDriveFileOutlined sx={{ "&:hover": { cursor: "pointer" }, width: "5%" }} />)}
                                                        <FlexBetween width="95%" paddingLeft="5%">
                                                            <Text
                                                                sx={{ "&:hover": { color: "blue", textDecoration: "underline" } }}
                                                            >
                                                                {item.path.substring(item.path.lastIndexOf('/') + 1)}
                                                            </Text>
                                                            {checkPresenceInScannedResult(item.path.substring(item.path.lastIndexOf('/') + 1)) && (
                                                                <PriorityHigh sx={{ color: "red" }} />
                                                            )}
                                                        </FlexBetween>
                                                    </Box>
                                                </TableCell>
                                                <TableCell> <Text> {item.type} </Text> </TableCell>
                                            </TableRow>
                                        </>
                                    )
                                }))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Box>
            ) : (
                <Box
                    height="40vh"
                    width="100%"
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                >
                    <CircularProgress
                        color="secondary"
                        size="4rem"
                    />
                </Box>
            )}

            {Boolean(repoContents) && (
                <Box
                    width="30%"
                    margin="auto"
                    marginTop="30px"
                    marginBottom="150px"
                >
                    <Button
                        sx={{ color: "white", backgroundColor: "#6495ED", width: "100%", margin: "auto", "&:hover": { backgroundColor: "#6495ED", transform: "scale(1.01)" } }}
                        onClick={() => {
                            navigate("/resultspage");
                        }}
                    >
                        checkout detailed report
                    </Button>
                </Box>
            )}

            <Footer />
        </>
    )

}


export default RepositoryTree;