import React from 'react';
import { useState, useEffect, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import {
    useMediaQuery,
    Box,
    CircularProgress,
    Divider,
    InputBase,
    Button,
    Select,
    MenuItem,
    FormControl
} from "@mui/material";
import { setLogout, setLogin, setGitProfile, setScannedResult, setRepository } from "../reduxState";
import Navbar from '../components/Navbar';
import Text from '../components/Text';
import Footer from '../components/Footer';
import 'animate.css';
import Typewriter from 'typewriter-effect';
import { Block } from '@mui/icons-material';

const Dashboard = () => {

    const [repositories, setRepositories] = useState([]);
    const [selectedRepo, setSelectedRepo] = useState("");
    const [loading, setLoading] = useState(true);
    const token = useSelector(state => state.token);
    const gitProfile = useSelector(state => state.gitProfile);
    const scannedResult = useSelector(state => state.scannedResult);
    const reduxRepository = useSelector(state => state.repository);
    const reduxBranch = useSelector(state => state.branch);
    const [openButtonText, setOpenButtonText] = useState("open");
    const [authenticationDone, setAuthenticationDone] = useState(false);
    const [repoInput, setRepoInput] = useState("");
    const [buttonDisabled, setButtonDisabled] = useState(false);
    const [scanButtonDisabled, setScanButtonDisabled] = useState(false);
    const [errorFetching, setErrorFetching] = useState(false);
    const [repository, setRepository] = useState(null);
    const [branch, setBranch] = useState("");
    const isLargeScreen = useMediaQuery("(min-width : 1000px)");
    const [scanprogress, setscanprogress] = useState(0);
    const [scanvalue, setscanvalue] = useState(null)
    const { appname } = useParams();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const boxRef = useRef(null);

    // function for getting the user's github access token
    const getGitUserAccessToken = async (userAuthCode) => {
        try {
            const response = await fetch(`${process.env.REACT_APP_BACKEND_BASEURL}/auth/getGitAccessToken`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    userAuthCode
                })
            });
            const res = await response.json();

            if (res.status === 201) {
                dispatch(setLogin({
                    token: res.jsonresponse.access_token,
                    authTokenType: "github"
                }));
                dispatch(setGitProfile({
                    gitProfile: res.profileInfo
                }))
                setTimeout(() => {
                    setAuthenticationDone(true);
                }, 1500);
            }

            else if (res.status === 422) {
                alert("Authentication Failed");
                dispatch(setLogout());
                navigate("/");
            }
        }
        catch (error) {
            alert("Server not responding :(");
            navigate("/");
        }
    }

    // function for getting the user's gitlab access token
    const getGitlabUserAccessToken = async (userAuthCode) => {
        try {
            const response = await fetch(`${process.env.REACT_APP_BACKEND_BASEURL}/auth/getGitlabAccessToken`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    userAuthCode
                })
            });
            const res = await response.json();

            if (res.status === 201) {
                dispatch(setLogin({
                    token: res.jsonresponse.access_token,
                    authTokenType: "gitlab"
                }));
                dispatch(setGitProfile({
                    gitProfile: res.profileInfo
                }))
                setTimeout(() => {
                    setAuthenticationDone(true);
                }, 1500);
            }

            else if (res.status === 422) {
                alert("Authentication Failed");
                dispatch(setLogout());
                navigate("/");
            }
        }
        catch (error) {
            alert("Server not responding :(");
            navigate("/");
        }
    }

    /* function for getting user's bitbucket access token */
    const getBitbucketUserAccessToken = async (userAuthCode) => {
        try {
      
            const response = await fetch(`${process.env.REACT_APP_BACKEND_BASEURL}/auth/getBitbucketAccessToken`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    userAuthCode
                })
            });
            const res = await response.json();

            if (res.status === 201) {
                dispatch(setLogin({
                    token: res.jsonresponse.access_token,
                    authTokenType: "bitbucket"
                }));
                dispatch(setGitProfile({
                    gitProfile: res.profileInfo
                }))
                setTimeout(() => {
                    setAuthenticationDone(true);
                }, 1500);
            }

            else if (res.status === 422) {
                alert("Authentication Failed");
                dispatch(setLogout());
                navigate("/");
            }
        }
        catch (error) {
            alert("Server not responding :(");
            navigate("/");
        }
    }

    /* Function for fetching a repository  */
    const getRepository = async (event) => {
        try {
            if (appname === "gitlab")
                var modifiedRepoInput = repoInput.replace(/\//g, "%2F");

            const url = appname === "github" ? `https://api.github.com/repos/${gitProfile.login}/${repoInput}/branches` :
                appname === "gitlab" ? `https://gitlab.com/api/v4/projects/${modifiedRepoInput}/repository/branches` :
                    `https://api.bitbucket.org/2.0/repositories/${repoInput}/refs/branches`;
            const response = await fetch(url, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            });
            const res = await response.json();

            if (response.status === 401) {
                dispatch(setLogout());
                navigate("/");
            }
            else if (response.status === 404) {
                setErrorFetching(true);
                setRepository(null);
            }

            else {
                setRepository(res);
                setBranch(appname === "bitbucket" ? res.values[0].name : res[0].name);
                setOpenButtonText("view");
            }
            setTimeout(() => {
                event.target.disabled = false;
                setButtonDisabled(false);
            }, 1000);
        }
        catch (error) {
            alert("Error in Fetching Repository");
        }
    }

    /* function for calling scan api of backend server */
    const callScanAPI = async (codeFiles) => {
        try {
            const response = await fetch(`${process.env.REACT_APP_BACKEND_BASEURL}/model/scanRepository`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    sourceCodeFiles: codeFiles,
                    web_url: gitProfile.web_url, 
                    repository: repoInput, 
                    branch
                  })
            });

            if (response.status === 422)
                throw new Error();

            const results = await response.json();
            console.log(results);
            dispatch(setScannedResult({
                repository: repoInput,
                branch: branch,
                scannedResult: results
            }));
        }
        catch (error) {
            throw new Error();
        }
    }

    /* functions for gathering all source code files in object */
    const gatherFilesInObjectGitHub = async (event) => {
        setscanvalue('Gathering all code files')
        await delay(1000);
        const codeFiles = {};
        try {
            const headers = {
                Authorization: `Bearer ${token}`
            };
            const branchUrl = `https://api.github.com/repos/${gitProfile.login}/${repoInput}/branches/${branch}`;
            const branchResponse = await fetch(branchUrl, { headers });
            if (!branchResponse.ok) {
                alert('Error fetching repository contents:');
                throw new Error();
            }
            setscanprogress(10)

            setscanvalue('Fetching repository tree structure')
            await delay(1000);

            const branchData = await branchResponse.json();
            const sha = branchData.commit.sha;

            // Fetch the tree structure of the repository
            const baseUrl = `https://api.github.com/repos/${gitProfile.login}/${repoInput}/git/trees/${sha}?recursive=1`;
            const response = await fetch(baseUrl, { headers });
            if (response.status === 401) {
                dispatch(setLogout());
                navigate("/");
            }
            const data = await response.json();
            const tree = data.tree;

            setscanprogress(15)


            // Filter out only Js or Java files
            const jsFiles = tree.filter(file => file.path.endsWith('.js') || file.path.endsWith(".java"));

            if (jsFiles.length === 0) {
                alert("No Java or Javascript files found in this repository");
                event.target.disabled = false;
                setScanButtonDisabled(false);
                return;
            }

            setscanvalue('Fetching contents')
            await delay(2000);
            // Fetch contents of each Js or Java file
            const fileContentsPromises = jsFiles.map(async file => {
                const fileResponse = await fetch(file.url, { headers });
                if (fileResponse.status === 401) {
                    dispatch(setLogout());
                    navigate("/");
                }
                if (!fileResponse.ok) {
                    alert('Error fetching repository contents:');
                    throw new Error();
                }

                const fileData = await fileResponse.json();
                const fileContent = atob(fileData.content);
                codeFiles[file.path] = fileContent;
            });

            setscanprogress(40)
            setscanvalue('Scanning')

            await Promise.all(fileContentsPromises);
            await callScanAPI(codeFiles);

            setscanprogress(100);
            setscanvalue('completed');
            await delay(2000);

            event.target.disabled = false;
            setScanButtonDisabled(false);
            boxRef.current.scrollIntoView({ behavior: "smooth" });

        } catch (error) {
            console.log('error is ... ', error)
            alert('Error in Scanning Repository');
            event.target.disabled = false;
            setScanButtonDisabled(false);
        }
    }

    const gatherFilesInObjectGitLab = async (event) => {

        setscanvalue('Gathering all code files')
        await delay(1000);

        const codeFiles = {};
        try {
            const headers = {
                Authorization: `Bearer ${token}`
            };
            let page = 1;
            let tree = [];
            let moreResults = true;

            setscanprogress(10)

            setscanvalue('Fetching repository tree structure')
            await delay(1000);

            // Fetch the repository tree with pagination
            while (moreResults) {
                const treeUrl = `https://gitlab.com/api/v4/projects/${encodeURIComponent(repoInput)}/repository/tree?ref=${branch}&recursive=true&per_page=100&page=${page}`;
                const treeResponse = await fetch(treeUrl, { headers });
                if (!treeResponse.ok) {
                    alert('Error fetching repository contents:');
                    throw new Error();
                }

                const treeData = await treeResponse.json();
                if (treeData.length === 0) {
                    moreResults = false;
                } else {
                    tree = tree.concat(treeData);
                    page += 1;
                }
            }

            setscanprogress(15)

            // Filter out only Js or Java files
            const jsFiles = tree.filter(file => file.type === 'blob' && (file.path.endsWith('.js') || file.path.endsWith(".java")));

            if (jsFiles.length === 0) {
                alert("No Java or Javascript files found in this repository");
                event.target.disabled = false;
                setScanButtonDisabled(false);
                return;
            }


            setscanvalue('Fetching contents')
            await delay(2000);

            // Fetch contents of each Java file
            const fileContentsPromises = jsFiles.map(async file => {
                const fileContentUrl = `https://gitlab.com/api/v4/projects/${encodeURIComponent(repoInput)}/repository/files/${encodeURIComponent(file.path)}/raw?ref=${branch}`;
                const fileResponse = await fetch(fileContentUrl, { headers });
                if (fileResponse.status === 401) {
                    dispatch(setLogout());
                    navigate("/");
                }
                if (!fileResponse.ok) {
                    alert('Error fetching repository contents:');
                    throw new Error();
                }

                const fileContent = await fileResponse.text();
                codeFiles[file.path] = fileContent;
            });


            setscanprogress(40)
            setscanvalue('Scanning')

            await Promise.all(fileContentsPromises);
            await callScanAPI(codeFiles);

            setscanprogress(100);
            setscanvalue('completed');
            await delay(2000);

            event.target.disabled = false;
            setScanButtonDisabled(false);
            boxRef.current.scrollIntoView({ behavior: "smooth" });

        } catch (error) {
            alert('Error in Scanning Repository');
            event.target.disabled = false;
            setScanButtonDisabled(false);
        }
    }

    const gatherFilesInObjectBitbucket = async (event) => {
        setscanvalue('Gathering all code files');
        await delay(1000);

        const codeFiles = {};
        try {
            const headers = {
                Authorization: `Bearer ${token}`
            };

            // Fetch branch details to get the latest commit hash
            const branchUrl = `https://api.bitbucket.org/2.0/repositories/${repoInput}/refs/branches/${branch}`;
            const branchResponse = await fetch(branchUrl, { headers });
            if (!branchResponse.ok) {
                alert('Error fetching branch information');
                throw new Error('Error fetching branch information');
            }
            const branchData = await branchResponse.json();
            const commitHash = branchData.target.hash;

            setscanprogress(15);
            setscanvalue('Fetching repository contents');
            await delay(1000);

            // Function to recursively fetch files
            const fetchFilesRecursively = async (path = '') => {
                const contentsUrl = `https://api.bitbucket.org/2.0/repositories/${repoInput}/src/${commitHash}/${path}`;
                const contentsResponse = await fetch(contentsUrl, { headers });
                if (!contentsResponse.ok) {
                    throw new Error(`Error fetching contents at path: ${path}`);
                }
                const contentsData = await contentsResponse.json();

                // Iterate over each item in the directory
                for (const item of contentsData.values) {
                    if (item.type === 'commit_file') {
                        if (item.path.endsWith('.js') || item.path.endsWith('.java')) {
                            // Fetch file content
                            const fileResponse = await fetch(
                                `https://api.bitbucket.org/2.0/repositories/${repoInput}/src/${commitHash}/${item.path}`,
                                { headers }
                            );
                            if (!fileResponse.ok) {
                                throw new Error(`Error fetching file contents: ${item.path}`);
                            }
                            const fileContent = await fileResponse.text();
                            codeFiles[item.path] = fileContent;
                        }
                    } else if (item.type === 'commit_directory') {
                        await fetchFilesRecursively(item.path);
                    }
                }
            };
            await fetchFilesRecursively();

            if (Object.keys(codeFiles).length === 0) {
                alert("No Java or JavaScript files found in this repository");
                event.target.disabled = false;
                setScanButtonDisabled(false);
                return;
            }

            setscanprogress(40);
            setscanvalue('Scanning');

            await callScanAPI(codeFiles);

            setscanprogress(100);
            setscanvalue('Completed');
            await delay(2000);

            event.target.disabled = false;
            setScanButtonDisabled(false);
            boxRef.current.scrollIntoView({ behavior: "smooth" });

        } catch (error) {
            alert('Error in Scanning Repository');
            event.target.disabled = false;
            setScanButtonDisabled(false);
        }
    };


    function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    useEffect(() => {

        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const userAuthCode = urlParams.get("code");

        if (token) {
            setTimeout(() => {
                setAuthenticationDone(true);
            }, 400);
            return;
        }

        // Now getting users access_tokens   
        if (!token && userAuthCode && appname === "github")
            getGitUserAccessToken(userAuthCode);

        else if (!token && userAuthCode && appname === "gitlab")
            getGitlabUserAccessToken(userAuthCode);

        else if (!token && userAuthCode && appname === "bitbucket")
            getBitbucketUserAccessToken(userAuthCode);

        else if (!userAuthCode && !token)
            navigate("/");

    }, [])

    useEffect(() => {
        setErrorFetching(false);
        setRepository(null);
        setBranch("");
    }, [repoInput])


    // use effect for fetching all user repositories
    useEffect(() => {
        const fetchRepositories = async () => {
            try {
                let response;

                // Fetch repositories based on the app (GitHub or GitLab)
                if (appname === "github") {
                    response = await fetch('https://api.github.com/user/repos', {
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    });
                } else if (appname === "gitlab") {
                    response = await fetch('https://gitlab.com/api/v4/projects?membership=true', {
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    });
                }
                else if (appname === "bitbucket") {
                    response = await fetch('https://api.bitbucket.org/2.0/repositories?role=admin', {
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    });
                }

                if (response && response.ok) {
                    const data = await response.json();

                    if (appname === "gitlab") {
                        // For GitLab, modify the data to combine namespace and name for each project
                        const modifiedData = data.map(project => {
                            return {
                                fullName: project.path_with_namespace,
                                id: project.id,
                                namespace: project.namespace.path,
                                name: project.name
                            };
                        });
                        setRepositories(modifiedData);
                    }
                    else if (appname === "bitbucket") {
                        setRepositories(data.values);
                    }
                    else {
                        setRepositories(data);
                    }
                } else {
                    throw new Error();
                }
            } catch (error) {
                alert('Error fetching repositories:');
                dispatch(setLogout());
                navigate("/");
            } finally {
                setLoading(false);  // Stop the loading state
            }
        };
        if (token)
            fetchRepositories();
    }, [token]);


    return (

        <>
            {authenticationDone ? (
                <>
                    <Navbar pageType="dashboard" />

                    <Box  margin="3rem 0rem">
                        <>
                            <Text sx={{ fontFamily: "Kanit, sans-serif", fontWeight: "800", fontSize: isLargeScreen ? "3rem" : "2rem", textAlign: "center" }}>
                                Code Scrub
                            </Text>
                            <Text sx={{ fontFamily: "Kanit, sans-serif", fontWeight: "500", fontSize: isLargeScreen ? "2rem" : "1.5rem", textAlign: "center" }}>
                                AI Powered Developers' Assistant
                            </Text>
                            <Text textAlign={"center"} fontWeight="700" marginTop={isLargeScreen ? "30px" : "50px"} fontSize="1.2rem" color="red">
                                <Typewriter options={{
                                    strings: ["Tired of debugging? ",
                                        " Let AI do the heavy lifting... ",
                                        "Scan. Detect. Improve.  ",
                                        "   CodeScrub: Perfecting your code with precision."
                                    ],
                                    autoStart: true,
                                    loop: true,
                                }}
                                    onInit={(typewriter) => {
                                        typewriter.typeString()
                                            .callFunction(() => {
                                            
                                            })
                                            .pauseFor(1500)
                                            .deleteAll()
                                            .callFunction(() => {
                                                
                                            })
                                            .start();
                                    }}
                                />
                            </Text>
                        </>
                    </Box>


                    <Box
                        display="flex"
                        flexDirection={isLargeScreen ? "row" : "column"}
                        alignItems="center"
                        justifyContent="space-evenly"
                        padding={isLargeScreen ? "5.5rem 0rem" : "0rem 6%"}
                        backgroundColor="#E5E7E9"
                        pb={Boolean(scannedResult) ? "150px" : "200px"}
                    >
                        <Box
                            width={isLargeScreen ? "30%" : "90%"}
                            marginTop={isLargeScreen ? "0px" : "50px"}
                        >
                            <Box
                                width="70%"
                                height="70%"
                                margin="auto"
                            >
                                <img src={`${gitProfile.avatar_url}`} alt="img"
                                    style={{ height: "100%", width: "100%", objectFit: "cover", borderRadius: "50%", border: "5px solid white" }}
                                />
                            </Box>

                            <Divider sx={{ borderBottomWidth: "1.2px", margin: "10px 0px" }} />

                            <Text textAlign="center" fontWeight="1000" fontSize="1.5rem">
                                {gitProfile.login}
                            </Text>
                            {appname === "github" ? (
                                <>
                                    <Text fontSize="1.2rem" textAlign="center" mt="10px">
                                        {`Public Repositories : ${gitProfile.public_repos}`}
                                    </Text>
                                    <Text fontSize="1.2rem" textAlign="center">
                                        {`Private Repositories : ${gitProfile.total_private_repos}`}
                                    </Text>
                                </>
                            ) : (
                                <Text fontSize="1.2rem" textAlign="center">
                                    {`email : ${gitProfile.email}`}
                                </Text>
                            )}

                            <Divider sx={{ borderBottomWidth: "1.2px", margin: "10px 0px" }} />

                            <Text textAlign="center" sx={{ "&:hover": { transform: "scale(1.02)" } }}>
                                <a href={appname === "github" ? gitProfile.html_url : gitProfile.web_url}
                                    style={{ textDecoration: "none", color: "blue" }}
                                    target="_blank"
                                    rel="noreferrer"
                                >
                                    {appname === "github" ? gitProfile.html_url : gitProfile.web_url}
                                </a>
                            </Text>

                            <Button
                                    sx={{ color: "white", backgroundColor: "rgb(0, 113, 93)", width: "50%", margin: "20px 25%", "&:hover": { backgroundColor: "#6495ED", transform: "scale(1.01)" } }}
                                    onClick={() => {
                                        navigate("/scanhistory");
                                    }}
                                >
                                    View Previously Scanned Repositories
                                </Button>



                        </Box>

                        <Box
                            width={isLargeScreen ? "50%" : "100%"}
                        >

                            <Box
                                padding="1rem"
                                borderRadius="20px"
                                width={isLargeScreen ? "80%" : "95%"}
                                margin="50px auto"
                                backgroundColor="white"
                            >
                                <Text textAlign="center" fontWeight="bold" fontSize="1.5rem" margin="20px 0px">
                                    Open Repository
                                </Text>

                                {errorFetching && !buttonDisabled && (
                                    <>
                                        <Text color="red" margin="15px" textAlign="center">
                                            *Repository not found
                                        </Text>
                                    </>
                                )}

                                <Box
                                    width={isLargeScreen ? "80%" : "100%"}
                                    margin="30px auto"
                                >


                                    {/* repo fetcher */}


                                    <Box display="flex" justifyContent="center" margin="40px 0px">
                                        {loading ? (
                                            <CircularProgress />
                                        ) : (
                                            <Select
                                                value={selectedRepo}
                                                onChange={(event) => {
                                                    setRepoInput(event.target.value);
                                                    setOpenButtonText("open");
                                                    setRepository(null);
                                                }}

                                                displayEmpty
                                                fullWidth
                                               
                                            >
                                                <MenuItem value="" disabled>Select a repository</MenuItem>

                                                {appname === "github" ? (
                                                    repositories.map((repo) => (
                                                        <MenuItem key={repo.id} value={repo.name}>
                                                            {repo.name}
                                                        </MenuItem>
                                                    ))
                                                ) : appname === "gitlab" ? (
                                                    repositories.map((repo) => (
                                                        <MenuItem key={repo.id} value={repo.fullName}>
                                                            {repo.name}
                                                        </MenuItem>
                                                    ))
                                                ) : (
                                                    repositories.map((repo) => (
                                                        <MenuItem key={repo.id} value={repo.full_name}>
                                                            {repo.name}
                                                        </MenuItem>
                                                    )))}

                                            </Select>
                                        )}
                                    </Box>
                                    {Boolean(repoInput) && (
                                        <Box
                                            sx={{
                                                borderRadius: "10px",
                                                width: "100%",
                                                padding: "13px 20px",
                                                backgroundColor: "#E5E7E9",
                                                color: 'black', // Style as needed
                                                userSelect: 'none'
                                            }}
                                        >
                                            {repoInput}
                                        </Box>
                                    )}

                                    {Boolean(repository) && (
                                        <>
                                            <Text margin="35px 6px">
                                                Select Branch :
                                            </Text>

                                            <FormControl variant="standard" value={branch} sx={{ width: "100%" }}>
                                                <Select value={branch}
                                                    sx={{
                                                        backgroundColor: "white",
                                                        width: "100%",
                                                        height: "8vh",
                                                        borderRadius: "5px",
                                                        padding: "0px 7px",
                                                        boxShadow: "0px 0px 5px 1px silver",
                                                        "& .MuiSvgIcon-root": { width: "2rem" },
                                                        "& .MuiSelect-select:focus": { backgroundColor: "inherit" }
                                                    }}
                                                    input={<InputBase />}
                                                >
                                                    {appname !== "bitbucket" ? (
                                                        repository.map((item) => {
                                                            return (
                                                                <MenuItem key={item.commit.sha} value={item.name}
                                                                    onClick={() => { setBranch(item.name) }}
                                                                >
                                                                    {item.name}
                                                                </MenuItem>
                                                            )
                                                        })) : (
                                                        repository.values.map((item) => {
                                                            return (
                                                                <MenuItem key={item.target.hash} value={item.name}
                                                                    onClick={() => { setBranch(item.name) }}
                                                                >
                                                                    {item.name}
                                                                </MenuItem>
                                                            )
                                                        })
                                                    )}
                                                </Select>
                                            </FormControl>

                                        </>
                                    )}
                                </Box>

                                <Box width={isLargeScreen ? "80%" : "100%"} margin="30px auto" mt="30px">
                                    <Button
                                        sx={{ color: "white", backgroundColor: "#00b894", width: "50%", margin: "auto 25%", "&:hover": { backgroundColor: "#00b894", transform: "scale(1.04)" } }}
                                        onClick={(event) => {
                                            setscanprogress(0)
                                            setscanvalue('')
                                            if (!repoInput)
                                                return;

                                            if (Boolean(repository)) {
                                                if (appname === "gitlab" || appname === "bitbucket") {
                                                    const modifiedRepoInput = repoInput.replace(/\//g, "%2F");
                                                    navigate(`/repository/${modifiedRepoInput}/${branch}`);
                                                }
                                                else
                                                    navigate(`/repository/${repoInput}/${branch}`);
                                            }

                                            else {
                                                event.target.disabled = true;
                                                setButtonDisabled(true);
                                                getRepository(event);
                                            }
                                        }
                                        }
                                    >
                                        {!buttonDisabled ? openButtonText : (<> <CircularProgress sx={{ color: "white" }} size="1.5rem" /> </>)}
                                    </Button>
                                    
                                </Box>

                                {Boolean(repository) && (
                                    <>
                                        <Box width={isLargeScreen ? "80%" : "100%"} margin="30px auto" mt="30px">
                                            <Button
                                                sx={{ color: "white", backgroundColor: "#00b894", width: "50%", margin: "auto 25%", "&:hover": { backgroundColor: "#00b894", transform: "scale(1.04)" } }}
                                                onClick={(event) => {
                                                    setscanprogress(0)
                                                    setscanvalue('')
                                                    if (!Boolean(repository)) {
                                                        alert("Please open up a repository for scanning");
                                                        return;
                                                    }

                                                    else {
                                                        event.target.disabled = true;
                                                        setScanButtonDisabled(true);
                                                        if (appname === "github") {
                                                            gatherFilesInObjectGitHub(event);

                                                        }

                                                        else if (appname === "gitlab") {
                                                            gatherFilesInObjectGitLab(event);
                                                        }

                                                        else if (appname === "bitbucket") {
                                                            gatherFilesInObjectBitbucket(event);
                                                        }
                                                    }
                                                }
                                                }
                                            >
                                                {!scanButtonDisabled ? "Scan" : (<> <CircularProgress sx={{ color: "white" }} size="1.5rem" /> </>)}
                                            </Button>

                                            {scanButtonDisabled && (<Box style={{ fontSize: '1rem', height: "2rem" }} className="progress" margin='2rem 0' size='8rem'>
                                                <div className="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow={{ scanprogress }} aria-valuemin="0" aria-valuemax="100" style={{ width: `${scanprogress}%` }}>{scanprogress + "%"}     </div>

                                            </Box>)}

                                        </Box>

                                        {scanButtonDisabled && (
                                            <Box>
                                                <p style={{ color: 'red', fontSize: '1rem', textAlign: 'center', margin: '0.5rem 0' }}>
                                                    {scanvalue + '...'}
                                                </p>
                                            </Box>
                                        )}
                                    </>
                                )}

                            </Box>
                        </Box>
                    </Box>

                    {Boolean(scannedResult) && (
                        <Box
                            pb="100px"
                            pt="100px"
                            pl={isLargeScreen ? "0px" : "1%"}
                            pr={isLargeScreen ? "0px" : "1%"}
                            ref={boxRef}
                        >
                            <Text sx={{ fontFamily: "Kanit, sans-serif", fontWeight: "500", fontSize: isLargeScreen ? "2rem" : "1.5rem", textAlign: "center" }}>
                                Previously Scanned Repository
                            </Text>
                            <Box
                                width= {isLargeScreen ? "50%" :  "100%"}
                                margin="50px auto"
                                display="flex"
                                flexDirection= {isLargeScreen ? "row" : "column"}

                            
                            >
                                <Button
                                    sx={{ color: "white", padding:"1%", backgroundColor: "#6495ED", width: isLargeScreen ? "40%" :  "50%", margin: isLargeScreen ? "auto 2%" : "2% 25%", "&:hover": { backgroundColor: "#6495ED", transform: "scale(1.01)" } }}
                                    onClick={() => {
                                        if (appname === "gitlab" || appname === "bitbucket") {
                                            const modifiedRepoInput = reduxRepository.replace(/\//g, "%2F");
                                            navigate(`/tree/${modifiedRepoInput}/${reduxBranch}`);
                                        }
                                        else
                                            navigate(`/tree/${reduxRepository}/${reduxBranch}`);
                                    }}
                                >
                                    checkout repository tree
                                </Button>

                                <Button
                                    sx={{ color: "white", padding:"1%",backgroundColor: "#6495ED", width: isLargeScreen ? "40%" :  "50%", margin: isLargeScreen ? "auto 2%" : "2% 25%", "&:hover": { backgroundColor: "#6495ED", transform: "scale(1.01)" } }}
                                    onClick={() => {
                                        navigate("/resultspage");
                                    }}
                                >
                                    checkout detailed report
                                </Button>
                            </Box>
                        </Box>
                    )}

                    <Footer />
                </>

            ) : (
                <>
                    <Box
                        height="100vh"
                        width="100%"
                        display="flex"
                        justifyContent="center"
                        alignItems="center"
                    >
                        <CircularProgress
                            color="secondary"
                            size="4rem"
                        />
                    </Box>
                </>
            )
            }
        </>
    )
}

export default Dashboard;











