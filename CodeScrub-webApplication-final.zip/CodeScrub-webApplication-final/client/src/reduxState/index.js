import { createSlice } from '@reduxjs/toolkit';

const myReducer = createSlice({
    name: "myReducer",
    initialState: {
        token: null,
        authTokenType: null,
        gitProfile: null,
        repository: null,
        branch: null,
        scannedResult: null
    },
    reducers: {
        setLogin: (state, action) => {
            state.token = action.payload.token;
            state.authTokenType = action.payload.authTokenType;
        },
        setLogout: (state) => {
            state.token = null;
            state.authTokenType = null;
            state.gitProfile = null;
            state.repository = null;
            state.branch = null;
            state.scannedResult = null;
        },
        setGitProfile: (state, action) => {
            state.gitProfile = action.payload.gitProfile;
        },
        setScannedResult: (state, action) => {
            state.repository = action.payload.repository;
            state.branch = action.payload.branch;
            state.scannedResult = action.payload.scannedResult ? action.payload.scannedResult : "No results found for this scan";
        },
        setRepository: (state, action) => {
            state.repository = action.payload.repository;
        }
    }
});

export const { setLogin, setLogout, setGitProfile, setScannedResult, setRepository } = myReducer.actions;
export default myReducer.reducer;
